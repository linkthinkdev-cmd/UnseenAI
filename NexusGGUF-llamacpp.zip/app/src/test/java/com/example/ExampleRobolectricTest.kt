package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.gguf.GgufParser
import com.example.data.gguf.GgufSampleGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NexusGGUF", appName)
    }

    @Test
    fun `generate and parse sample GGUF model`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sampleFile = GgufSampleGenerator.getOrGenerateSampleModel(context)
        assertTrue(sampleFile.exists())
        assertTrue(sampleFile.length() > 0)

        val parser = GgufParser(context)
        val details = parser.parseFile(sampleFile)
        assertTrue(details.isValid)
        assertEquals("llama", details.architecture)
        assertEquals("Q4_0", details.quantization)
        assertTrue(details.tensorCount > 0)
        assertTrue(details.metadataKvCount > 0)
    }
}
