// Jembatan JNI sederhana antara Kotlin dan llama.cpp (inferensi GGUF on-device).
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <unistd.h>
#include <vector>

#include "llama.h"

#define TAG "NexusLlama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

struct Engine {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    FILE *file = nullptr;
    int n_ctx = 0;
    std::atomic<bool> cancel{false};
    // statistik generasi terakhir
    double prompt_tokens = 0, prompt_ms = 0, gen_tokens = 0, gen_ms = 0;
    int stop_reason = 0; // 0=eos 1=panjang maksimum 2=dibatalkan 3=konteks penuh
};

std::string g_last_error;
bool g_backend_ready = false;

void log_callback(ggml_log_level level, const char *text, void *) {
    int prio = ANDROID_LOG_INFO;
    if (level == GGML_LOG_LEVEL_ERROR) prio = ANDROID_LOG_ERROR;
    else if (level == GGML_LOG_LEVEL_WARN) prio = ANDROID_LOG_WARN;
    else if (level == GGML_LOG_LEVEL_DEBUG) return;
    __android_log_print(prio, TAG, "%s", text);
}

double now_ms() {
    using namespace std::chrono;
    return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

// Jumlah byte di ujung string yang merupakan awal karakter UTF-8 yang belum lengkap.
size_t utf8_incomplete_tail(const std::string &s) {
    const size_t n = s.size();
    for (size_t back = 1; back <= 3 && back <= n; back++) {
        const unsigned char c = static_cast<unsigned char>(s[n - back]);
        if ((c & 0xC0) == 0x80) continue; // byte lanjutan, cari byte awal
        const size_t need = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
        return need > back ? back : 0;
    }
    return 0;
}

std::string bytes_to_string(JNIEnv *env, jbyteArray arr) {
    if (!arr) return std::string();
    const jsize len = env->GetArrayLength(arr);
    std::string out(static_cast<size_t>(len), '\0');
    if (len > 0) env->GetByteArrayRegion(arr, 0, len, reinterpret_cast<jbyte *>(&out[0]));
    return out;
}

jbyteArray string_to_bytes(JNIEnv *env, const char *data, size_t len) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(len));
    if (arr && len > 0) env->SetByteArrayRegion(arr, 0, static_cast<jsize>(len), reinterpret_cast<const jbyte *>(data));
    return arr;
}

void free_engine(Engine *e) {
    if (!e) return;
    if (e->ctx) llama_free(e->ctx);
    if (e->model) llama_model_free(e->model);
    if (e->file) fclose(e->file);
    delete e;
}

bool abort_callback(void *data) {
    return static_cast<Engine *>(data)->cancel.load();
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_example_engine_LlamaBridge_nativeLoadModel(JNIEnv *, jobject, jint fd, jint n_ctx,
                                                    jint n_threads) {
    g_last_error.clear();
    if (!g_backend_ready) {
        llama_log_set(log_callback, nullptr);
        llama_backend_init();
        g_backend_ready = true;
        LOGI("%s", llama_print_system_info());
    }

    // dup supaya Kotlin bebas menutup ParcelFileDescriptor miliknya.
    const int dup_fd = dup(fd);
    if (dup_fd < 0) {
        g_last_error = "Tidak bisa menduplikasi file descriptor model";
        return 0;
    }
    FILE *f = fdopen(dup_fd, "rb");
    if (!f) {
        close(dup_fd);
        g_last_error = "fdopen gagal membuka file model";
        return 0;
    }

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.load_mode = LLAMA_LOAD_MODE_MMAP; // model dipetakan ke memori, tidak disalin ke RAM

    llama_model *model = llama_model_load_from_file_ptr(f, mp);
    if (!model) {
        fclose(f);
        g_last_error = "llama.cpp gagal memuat model (format/arsitektur tidak didukung atau file rusak)";
        return 0;
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(n_ctx > 0 ? n_ctx : 2048);
    cp.n_threads = n_threads > 0 ? n_threads : 4;
    cp.n_threads_batch = cp.n_threads;

    llama_context *ctx = llama_init_from_model(model, cp);
    if (!ctx) {
        llama_model_free(model);
        fclose(f);
        g_last_error = "Gagal membuat konteks (RAM tidak cukup? coba context length lebih kecil)";
        return 0;
    }

    Engine *e = new Engine();
    e->model = model;
    e->ctx = ctx;
    e->vocab = llama_model_get_vocab(model);
    e->file = f;
    e->n_ctx = static_cast<int>(llama_n_ctx(ctx));
    llama_set_abort_callback(ctx, abort_callback, e);
    LOGI("Model dimuat: n_ctx=%d threads=%d", e->n_ctx, cp.n_threads);
    return reinterpret_cast<jlong>(e);
}

JNIEXPORT void JNICALL
Java_com_example_engine_LlamaBridge_nativeFreeModel(JNIEnv *, jobject, jlong handle) {
    free_engine(reinterpret_cast<Engine *>(handle));
}

JNIEXPORT jstring JNICALL
Java_com_example_engine_LlamaBridge_nativeLastError(JNIEnv *env, jobject) {
    return env->NewStringUTF(g_last_error.c_str()); // hanya ASCII
}

JNIEXPORT jint JNICALL
Java_com_example_engine_LlamaBridge_nativeContextSize(JNIEnv *, jobject, jlong handle) {
    Engine *e = reinterpret_cast<Engine *>(handle);
    return e ? e->n_ctx : 0;
}

JNIEXPORT jint JNICALL
Java_com_example_engine_LlamaBridge_nativeTrainContext(JNIEnv *, jobject, jlong handle) {
    Engine *e = reinterpret_cast<Engine *>(handle);
    return e ? llama_model_n_ctx_train(e->model) : 0;
}

JNIEXPORT void JNICALL
Java_com_example_engine_LlamaBridge_nativeSetThreads(JNIEnv *, jobject, jlong handle, jint n) {
    Engine *e = reinterpret_cast<Engine *>(handle);
    if (e && n > 0) llama_set_n_threads(e->ctx, n, n);
}

JNIEXPORT void JNICALL
Java_com_example_engine_LlamaBridge_nativeCancel(JNIEnv *, jobject, jlong handle) {
    Engine *e = reinterpret_cast<Engine *>(handle);
    if (e) e->cancel.store(true);
}

// Menerapkan chat template bawaan model. Mengembalikan null jika model tidak punya
// template / template tidak didukung (Kotlin lalu memakai template cadangan).
JNIEXPORT jbyteArray JNICALL
Java_com_example_engine_LlamaBridge_nativeApplyChatTemplate(JNIEnv *env, jobject, jlong handle,
                                                            jobjectArray roles,
                                                            jobjectArray contents) {
    Engine *e = reinterpret_cast<Engine *>(handle);
    if (!e) return nullptr;
    const char *tmpl = llama_model_chat_template(e->model, nullptr);
    if (!tmpl) return nullptr;

    const jsize n = env->GetArrayLength(roles);
    std::vector<std::string> role_s(n), content_s(n);
    std::vector<llama_chat_message> msgs(n);
    size_t total = 0;
    for (jsize i = 0; i < n; i++) {
        jbyteArray r = static_cast<jbyteArray>(env->GetObjectArrayElement(roles, i));
        jbyteArray c = static_cast<jbyteArray>(env->GetObjectArrayElement(contents, i));
        role_s[i] = bytes_to_string(env, r);
        content_s[i] = bytes_to_string(env, c);
        env->DeleteLocalRef(r);
        env->DeleteLocalRef(c);
        msgs[i].role = role_s[i].c_str();
        msgs[i].content = content_s[i].c_str();
        total += role_s[i].size() + content_s[i].size();
    }

    std::vector<char> buf(total * 2 + 1024);
    int32_t len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(),
                                            static_cast<int32_t>(buf.size()));
    if (len > static_cast<int32_t>(buf.size())) {
        buf.resize(static_cast<size_t>(len) + 1);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(),
                                        static_cast<int32_t>(buf.size()));
    }
    if (len < 0) return nullptr;
    return string_to_bytes(env, buf.data(), static_cast<size_t>(len));
}

// Statistik generasi terakhir: [promptTokens, promptMs, genTokens, genMs, stopReason]
JNIEXPORT jdoubleArray JNICALL
Java_com_example_engine_LlamaBridge_nativeStats(JNIEnv *env, jobject, jlong handle) {
    Engine *e = reinterpret_cast<Engine *>(handle);
    jdoubleArray arr = env->NewDoubleArray(5);
    if (!e) return arr;
    jdouble v[5] = {e->prompt_tokens, e->prompt_ms, e->gen_tokens, e->gen_ms,
                    static_cast<jdouble>(e->stop_reason)};
    env->SetDoubleArrayRegion(arr, 0, 5, v);
    return arr;
}

// Return: jumlah token yang dihasilkan (>= 0) atau kode error negatif:
// -1 handle tidak valid, -2 prompt terlalu panjang, -3 tokenisasi gagal,
// -4 decode gagal, -5 exception pada callback.
JNIEXPORT jint JNICALL
Java_com_example_engine_LlamaBridge_nativeGenerate(JNIEnv *env, jobject, jlong handle,
                                                   jbyteArray jprompt, jint max_tokens,
                                                   jfloat temp, jfloat top_p, jint top_k,
                                                   jfloat repeat_penalty, jint seed,
                                                   jobject callback) {
    g_last_error.clear();
    Engine *e = reinterpret_cast<Engine *>(handle);
    if (!e || !e->ctx) {
        g_last_error = "Model belum dimuat";
        return -1;
    }
    e->cancel.store(false);
    e->prompt_tokens = e->prompt_ms = e->gen_tokens = e->gen_ms = 0;
    e->stop_reason = 0;

    jclass cb_cls = env->GetObjectClass(callback);
    jmethodID on_token = env->GetMethodID(cb_cls, "onToken", "([B)Z");
    if (!on_token) {
        g_last_error = "Callback tidak valid";
        return -5;
    }

    const std::string prompt = bytes_to_string(env, jprompt);

    // --- tokenisasi ---------------------------------------------------------
    bool add_special = llama_vocab_get_add_bos(e->vocab);
    const llama_token bos = llama_vocab_bos(e->vocab);
    if (add_special && bos != LLAMA_TOKEN_NULL) {
        const char *bos_text = llama_vocab_get_text(e->vocab, bos);
        if (bos_text && *bos_text && prompt.rfind(bos_text, 0) == 0) add_special = false;
    }
    int32_t n_tok = -llama_tokenize(e->vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                                    nullptr, 0, add_special, true);
    if (n_tok <= 0) {
        g_last_error = "Tokenisasi prompt gagal";
        return -3;
    }
    std::vector<llama_token> tokens(static_cast<size_t>(n_tok));
    n_tok = llama_tokenize(e->vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                           tokens.data(), static_cast<int32_t>(tokens.size()), add_special, true);
    if (n_tok <= 0) {
        g_last_error = "Tokenisasi prompt gagal";
        return -3;
    }
    tokens.resize(static_cast<size_t>(n_tok));

    if (n_tok >= e->n_ctx - 4) {
        g_last_error = "Prompt terlalu panjang (" + std::to_string(n_tok) +
                       " token) untuk context length " + std::to_string(e->n_ctx) +
                       ". Naikkan context length di Settings atau mulai chat baru.";
        return -2;
    }

    // --- sampler ------------------------------------------------------------
    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(e->vocab), 64,
                                                               repeat_penalty > 0 ? repeat_penalty : 1.0f,
                                                               0.0f, 0.0f));
    if (temp <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        if (top_k > 0) llama_sampler_chain_add(smpl, llama_sampler_init_top_k(top_k));
        if (top_p > 0.0f && top_p < 1.0f) llama_sampler_chain_add(smpl, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(seed < 0 ? LLAMA_DEFAULT_SEED : static_cast<uint32_t>(seed)));
    }
    const size_t pen_from = tokens.size() > 64 ? tokens.size() - 64 : 0;
    for (size_t i = pen_from; i < tokens.size(); i++) llama_sampler_accept(smpl, tokens[i]);

    // --- prompt eval --------------------------------------------------------
    llama_memory_clear(llama_get_memory(e->ctx), true);
    const double t0 = now_ms();
    const int32_t n_batch = static_cast<int32_t>(llama_n_batch(e->ctx));
    for (int32_t i = 0; i < n_tok; i += n_batch) {
        const int32_t n_eval = std::min(n_batch, n_tok - i);
        llama_batch batch = llama_batch_get_one(tokens.data() + i, n_eval);
        const int32_t rc = llama_decode(e->ctx, batch);
        if (rc != 0) {
            llama_sampler_free(smpl);
            if (e->cancel.load()) {
                e->stop_reason = 2;
                return 0;
            }
            g_last_error = "llama_decode gagal pada prompt (kode " + std::to_string(rc) + ")";
            return -4;
        }
    }
    const double t1 = now_ms();
    e->prompt_tokens = n_tok;
    e->prompt_ms = t1 - t0;

    // --- generasi -----------------------------------------------------------
    int n_gen = 0;
    int n_pos = n_tok;
    std::string pending;
    int ret = 0;
    e->stop_reason = 1;

    auto emit = [&](const std::string &chunk) -> int { // 0 lanjut, 1 berhenti, -1 exception
        jbyteArray arr = string_to_bytes(env, chunk.data(), chunk.size());
        const jboolean cont = env->CallBooleanMethod(callback, on_token, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return -1;
        }
        return cont ? 0 : 1;
    };

    while (n_gen < max_tokens) {
        if (n_pos >= e->n_ctx - 1) {
            e->stop_reason = 3;
            break;
        }
        if (e->cancel.load()) {
            e->stop_reason = 2;
            break;
        }

        llama_token tok = llama_sampler_sample(smpl, e->ctx, -1);
        if (llama_vocab_is_eog(e->vocab, tok)) {
            e->stop_reason = 0;
            break;
        }

        char piece[256];
        int32_t plen = llama_token_to_piece(e->vocab, tok, piece, sizeof(piece), 0, false);
        if (plen < 0) {
            std::vector<char> big(static_cast<size_t>(-plen));
            plen = llama_token_to_piece(e->vocab, tok, big.data(), static_cast<int32_t>(big.size()), 0, false);
            if (plen > 0) pending.append(big.data(), static_cast<size_t>(plen));
        } else if (plen > 0) {
            pending.append(piece, static_cast<size_t>(plen));
        }

        const size_t tail = utf8_incomplete_tail(pending);
        if (pending.size() > tail) {
            const std::string chunk = pending.substr(0, pending.size() - tail);
            pending.erase(0, chunk.size());
            const int r = emit(chunk);
            if (r == -1) { ret = -5; g_last_error = "Exception pada callback token"; break; }
            if (r == 1) { n_gen++; e->stop_reason = 2; break; }
        }
        n_gen++;

        llama_batch batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(e->ctx, batch) != 0) {
            if (e->cancel.load()) { e->stop_reason = 2; break; }
            ret = -4;
            g_last_error = "llama_decode gagal saat generasi";
            break;
        }
        n_pos++;
    }

    const double t2 = now_ms();
    e->gen_tokens = n_gen;
    e->gen_ms = t2 - t1;
    llama_sampler_free(smpl);
    return ret < 0 ? ret : n_gen;
}

} // extern "C"
