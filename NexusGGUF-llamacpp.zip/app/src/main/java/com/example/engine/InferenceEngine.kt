package com.example.engine

import android.content.Context
import android.net.Uri
import android.os.Debug
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import com.example.data.gguf.GgufModelDetails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

data class GenerationSettings(
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val repeatPenalty: Float = 1.1f,
    val maxTokens: Int = 512,
    val contextLength: Int = 4096,
    // Pakai ~setengah core: core "little" di HP justru memperlambat inferensi.
    val threads: Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 6),
    val systemPrompt: String = "You are a helpful, brilliant, and concise local AI assistant running directly on an Android device via GGUF neural weights.",
    val templateOverride: String = "Auto" // "Auto", "ChatML", "Llama3", "Mistral", "Raw"
)

data class GenerationMetrics(
    val timeToFirstTokenMs: Long = 0L,
    val tokensPerSecond: Double = 0.0,
    val totalTokens: Int = 0,
    val elapsedMs: Long = 0L,
    val memoryUsageMb: Double = 0.0,
    val isComplete: Boolean = false,
    val stopReason: String = ""
)

sealed class GenerationEvent {
    data class Token(val text: String, val fullText: String, val metrics: GenerationMetrics) : GenerationEvent()
    data class Complete(val fullText: String, val metrics: GenerationMetrics) : GenerationEvent()
    data class Error(val message: String) : GenerationEvent()
}

/** Mesin inferensi on-device berbasis llama.cpp. Sepenuhnya offline. */
class LocalInferenceEngine(private val context: Context) {

    @Volatile private var activeModel: GgufModelDetails? = null
    @Volatile private var handle: Long = 0L
    @Volatile private var loadedCtx: Int = 0
    private val cancelled = AtomicBoolean(false)
    private val nativeLock = Any()

    fun getActiveModel(): GgufModelDetails? = activeModel

    fun isModelLoaded(): Boolean = handle != 0L

    private fun effectiveContext(model: GgufModelDetails, settings: GenerationSettings): Int {
        val trainCtx = if (model.contextLength > 0) model.contextLength else Int.MAX_VALUE
        return settings.contextLength.coerceIn(512, 32768).coerceAtMost(trainCtx).coerceAtLeast(256)
    }

    private fun openFd(path: String): ParcelFileDescriptor? = try {
        if (path.startsWith("content://")) {
            context.contentResolver.openFileDescriptor(Uri.parse(path), "r")
        } else {
            ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Memuat model ke llama.cpp. Blocking — panggil dari thread IO.
     * @return null jika berhasil, atau pesan error.
     */
    fun loadModel(model: GgufModelDetails, settings: GenerationSettings): String? {
        if (!LlamaBridge.isAvailable) {
            return "Library native llama.cpp tidak ada di APK ini (build tanpa NDK?)."
        }
        cancelGeneration()
        return synchronized(nativeLock) { loadLocked(model, settings) }
    }

    private fun loadLocked(model: GgufModelDetails, settings: GenerationSettings): String? {
        freeLocked()

        val specs = DeviceTelemetry.getDeviceSpecs(context)
        if (model.fileSize > specs.totalRamBytes * 0.8) {
            return "Model ${model.formattedFileSize} terlalu besar untuk RAM perangkat " +
                "(${String.format("%.1f", specs.totalRamGb)} GB). Pakai model lebih kecil / kuantisasi lebih rendah."
        }

        val pfd = openFd(model.filePath)
            ?: return "Tidak bisa membuka file model. Impor ulang file .gguf-nya (izin akses mungkin hilang)."
        val ctxWanted = effectiveContext(model, settings)
        val h = try {
            LlamaBridge.nativeLoadModel(pfd.fd, ctxWanted, settings.threads)
        } finally {
            try { pfd.close() } catch (_: Exception) {}
        }
        if (h == 0L) {
            return LlamaBridge.nativeLastError().ifBlank { "Gagal memuat model." }
        }
        handle = h
        loadedCtx = ctxWanted
        activeModel = model
        cancelled.set(false)
        return null
    }

    fun unloadModel() {
        cancelGeneration()
        synchronized(nativeLock) { freeLocked() }
    }

    private fun freeLocked() {
        val h = handle
        handle = 0L
        activeModel = null
        loadedCtx = 0
        if (h != 0L) LlamaBridge.nativeFreeModel(h)
    }

    fun cancelGeneration() {
        cancelled.set(true)
        val h = handle
        if (h != 0L) LlamaBridge.nativeCancel(h)
    }

    /** Susun prompt. Mode "Auto" memakai chat template bawaan model (dari file GGUF-nya). */
    fun formatPrompt(
        systemPrompt: String,
        conversationHistory: List<Pair<String, String>>, // role to content
        newPrompt: String,
        template: String
    ): String {
        if (template == "Auto" && handle != 0L) {
            val roles = ArrayList<ByteArray>()
            val contents = ArrayList<ByteArray>()
            if (systemPrompt.isNotBlank()) {
                roles.add("system".toByteArray()); contents.add(systemPrompt.toByteArray(Charsets.UTF_8))
            }
            for ((role, content) in conversationHistory) {
                roles.add(role.toByteArray()); contents.add(content.toByteArray(Charsets.UTF_8))
            }
            roles.add("user".toByteArray()); contents.add(newPrompt.toByteArray(Charsets.UTF_8))

            val formatted = synchronized(nativeLock) {
                val h = handle
                if (h == 0L) null
                else LlamaBridge.nativeApplyChatTemplate(h, roles.toTypedArray(), contents.toTypedArray())
            }
            if (formatted != null) return String(formatted, Charsets.UTF_8)
        }
        return formatPromptFallback(systemPrompt, conversationHistory, newPrompt, template)
    }

    private fun formatPromptFallback(
        systemPrompt: String,
        conversationHistory: List<Pair<String, String>>,
        newPrompt: String,
        template: String
    ): String {
        val arch = activeModel?.architecture?.lowercase() ?: "llama"
        val resolvedTemplate = if (template != "Auto") template else {
            when {
                arch.contains("qwen") || arch.contains("smol") -> "ChatML"
                arch.contains("llama") -> "Llama3"
                arch.contains("mistral") -> "Mistral"
                else -> "ChatML"
            }
        }

        return when (resolvedTemplate) {
            "ChatML" -> buildString {
                append("<|im_start|>system\n$systemPrompt<|im_end|>\n")
                for ((role, content) in conversationHistory) {
                    append("<|im_start|>$role\n$content<|im_end|>\n")
                }
                append("<|im_start|>user\n$newPrompt<|im_end|>\n")
                append("<|im_start|>assistant\n")
            }
            "Llama3" -> buildString {
                append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n$systemPrompt<|eot_id|>\n")
                for ((role, content) in conversationHistory) {
                    append("<|start_header_id|>$role<|end_header_id|>\n$content<|eot_id|>\n")
                }
                append("<|start_header_id|>user<|end_header_id|>\n$newPrompt<|eot_id|>\n")
                append("<|start_header_id|>assistant<|end_header_id|>\n")
            }
            "Mistral" -> buildString {
                append("<s>[INST] <<SYS>>\n$systemPrompt\n<</SYS>>\n\n")
                for ((role, content) in conversationHistory) {
                    if (role == "user") append("$content [/INST] ") else append("$content </s><s>[INST] ")
                }
                append("$newPrompt [/INST]")
            }
            else -> buildString {
                append("System: $systemPrompt\n\n")
                for ((role, content) in conversationHistory) {
                    append("${role.replaceFirstChar { it.uppercase() }}: $content\n")
                }
                append("User: $newPrompt\nAssistant: ")
            }
        }
    }

    /** Generasi token streaming dari llama.cpp. */
    fun generateStreaming(
        prompt: String,
        settings: GenerationSettings
    ): Flow<GenerationEvent> = callbackFlow {
        val model = activeModel
        if (model == null || handle == 0L) {
            send(GenerationEvent.Error("Belum ada model GGUF yang dimuat. Buka tab Models, lalu muat sebuah model."))
            close()
            awaitClose { }
            return@callbackFlow
        }

        val worker = launch(Dispatchers.Default) {
            try {
                // Context length berubah di Settings -> muat ulang model.
                if (effectiveContext(model, settings) != loadedCtx) {
                    val err = loadModel(model, settings)
                    if (err != null) {
                        send(GenerationEvent.Error(err))
                        return@launch
                    }
                }
                cancelled.set(false)

                val start = SystemClock.elapsedRealtime()
                var firstTokenAt = 0L
                var count = 0
                var pss = Debug.getPss() / 1024.0
                val sb = StringBuilder()

                val callback = LlamaTokenCallback { bytes ->
                    if (cancelled.get()) return@LlamaTokenCallback false
                    val piece = String(bytes, Charsets.UTF_8)
                    sb.append(piece)
                    count++
                    val now = SystemClock.elapsedRealtime()
                    if (count == 1) firstTokenAt = now
                    if (count % 16 == 1) pss = Debug.getPss() / 1024.0
                    val genMs = now - firstTokenAt
                    val tps = if (count > 1 && genMs > 0) (count - 1) * 1000.0 / genMs else 0.0
                    trySend(
                        GenerationEvent.Token(
                            text = piece,
                            fullText = sb.toString(),
                            metrics = GenerationMetrics(
                                timeToFirstTokenMs = firstTokenAt - start,
                                tokensPerSecond = tps,
                                totalTokens = count,
                                elapsedMs = now - start,
                                memoryUsageMb = pss,
                                isComplete = false
                            )
                        )
                    )
                    true
                }

                var stats = DoubleArray(5)
                val rc = synchronized(nativeLock) {
                    val h = handle
                    if (h == 0L) {
                        -100
                    } else {
                        LlamaBridge.nativeSetThreads(h, settings.threads)
                        val r = LlamaBridge.nativeGenerate(
                            h,
                            prompt.toByteArray(Charsets.UTF_8),
                            settings.maxTokens.coerceAtLeast(1),
                            settings.temperature,
                            settings.topP,
                            settings.topK,
                            settings.repeatPenalty,
                            -1,
                            callback
                        )
                        stats = LlamaBridge.nativeStats(h)
                        r
                    }
                }

                if (rc < 0) {
                    val msg = if (rc == -100) "Model dilepas saat generasi berjalan."
                    else LlamaBridge.nativeLastError().ifBlank { "Generasi gagal (kode $rc)." }
                    send(GenerationEvent.Error(msg))
                    return@launch
                }

                val end = SystemClock.elapsedRealtime()
                val genTokens = stats[2]
                val genMs = stats[3]
                val tps = if (genMs > 0) genTokens * 1000.0 / genMs else 0.0
                val stop = when (stats[4].toInt()) {
                    0 -> "eos_token"
                    1 -> "max_tokens"
                    2 -> "cancelled"
                    3 -> "context_full"
                    else -> "unknown"
                }
                send(
                    GenerationEvent.Complete(
                        fullText = sb.toString(),
                        metrics = GenerationMetrics(
                            timeToFirstTokenMs = if (firstTokenAt > 0) firstTokenAt - start else end - start,
                            tokensPerSecond = tps,
                            totalTokens = count,
                            elapsedMs = end - start,
                            memoryUsageMb = Debug.getPss() / 1024.0,
                            isComplete = true,
                            stopReason = stop
                        )
                    )
                )
            } catch (t: Throwable) {
                try { send(GenerationEvent.Error(t.message ?: t.javaClass.simpleName)) } catch (_: Throwable) {}
            } finally {
                close()
            }
        }

        awaitClose {
            // Collector berhenti (mis. layar ditutup): hentikan native lebih cepat.
            cancelGeneration()
            worker.cancel()
        }
    }
}
