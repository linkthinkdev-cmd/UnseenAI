package com.example.engine

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build

data class DeviceSpecs(
    val totalRamBytes: Long,
    val availRamBytes: Long,
    val isLowMemory: Boolean,
    val cpuCores: Int,
    val supportedAbis: List<String>,
    val batteryPct: Int,
    val batteryTempCelsius: Float,
    val isCharging: Boolean
) {
    val totalRamGb: Double
        get() = totalRamBytes / (1024.0 * 1024.0 * 1024.0)

    val availRamGb: Double
        get() = availRamBytes / (1024.0 * 1024.0 * 1024.0)

    val usedRamGb: Double
        get() = (totalRamBytes - availRamBytes) / (1024.0 * 1024.0 * 1024.0)

    val ramUsagePercent: Int
        get() = if (totalRamBytes > 0) (((totalRamBytes - availRamBytes) * 100) / totalRamBytes).toInt() else 0
}

object DeviceTelemetry {

    fun getDeviceSpecs(context: Context): DeviceSpecs {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager.getMemoryInfo(memInfo)

        val cores = Runtime.getRuntime().availableProcessors()
        val abis = Build.SUPPORTED_ABIS.toList()

        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }

        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level != -1 && scale != -1) (level * 100 / scale.toFloat()).toInt() else 100

        val tempRaw = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempCelsius = tempRaw / 10.0f

        val status: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        return DeviceSpecs(
            totalRamBytes = memInfo.totalMem,
            availRamBytes = memInfo.availMem,
            isLowMemory = memInfo.lowMemory,
            cpuCores = cores,
            supportedAbis = abis,
            batteryPct = batteryPct,
            batteryTempCelsius = tempCelsius,
            isCharging = isCharging
        )
    }

    /**
     * Calculates KV cache memory requirement in bytes for given model architecture parameters and context length:
     * 2 (K & V) * layers * kv_heads * head_dim * context_length * 2 bytes (fp16)
     */
    fun calculateKvCacheBytes(
        blockCount: Int,
        headCount: Int,
        headCountKv: Int,
        embeddingLength: Int,
        contextLength: Int
    ): Long {
        val safeHeadCount = headCount.coerceAtLeast(1)
        val headDim = embeddingLength / safeHeadCount
        val safeKvHeads = if (headCountKv > 0) headCountKv else safeHeadCount

        // 2 (Key + Value) * blocks * kv_heads * head_dim * contextLength * 2 bytes per float16
        return 2L * blockCount * safeKvHeads * headDim * contextLength * 2L
    }

    fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024.0) {
            String.format("%.2f GB", mb / 1024.0)
        } else {
            String.format("%.1f MB", mb)
        }
    }
}
