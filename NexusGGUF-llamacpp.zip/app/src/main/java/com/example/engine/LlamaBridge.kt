package com.example.engine

/** Dipanggil dari kode native untuk setiap potongan teks (UTF-8 lengkap). Return false untuk berhenti. */
fun interface LlamaTokenCallback {
    fun onToken(piece: ByteArray): Boolean
}

/**
 * Jembatan JNI ke llama.cpp (lihat app/src/main/cpp/nexus_llama.cpp).
 * Semua string teks dikirim sebagai ByteArray UTF-8 agar aman untuk emoji / karakter non-Latin.
 */
object LlamaBridge {

    /** false jika library native tidak ada di APK (mis. build tanpa NDK). */
    val isAvailable: Boolean = try {
        System.loadLibrary("nexus_llama")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    }

    external fun nativeLoadModel(fd: Int, nCtx: Int, nThreads: Int): Long
    external fun nativeFreeModel(handle: Long)
    external fun nativeLastError(): String
    external fun nativeContextSize(handle: Long): Int
    external fun nativeTrainContext(handle: Long): Int
    external fun nativeSetThreads(handle: Long, n: Int)
    external fun nativeCancel(handle: Long)
    external fun nativeApplyChatTemplate(
        handle: Long,
        roles: Array<ByteArray>,
        contents: Array<ByteArray>
    ): ByteArray?

    /** [promptTokens, promptMs, genTokens, genMs, stopReason] dari generasi terakhir. */
    external fun nativeStats(handle: Long): DoubleArray

    external fun nativeGenerate(
        handle: Long,
        prompt: ByteArray,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        repeatPenalty: Float,
        seed: Int,
        callback: LlamaTokenCallback
    ): Int
}
