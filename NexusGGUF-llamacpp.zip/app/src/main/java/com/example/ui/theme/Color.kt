package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tema "Seen the Unseen" — diambil dari warna logo/wallpaper:
// ungu malam #210945, teal #15ADB0, pink #DE176A, marun #8C1046.
// (Nama variabel "Neural*" dipertahankan agar semua layar otomatis ikut berganti warna.)
val NeuralCyan = Color(0xFF1FC4C7)        // teal terang (aksen utama)
val NeuralCyanDark = Color(0xFF15ADB0)    // teal logo
val NeuralViolet = Color(0xFFDE176A)      // pink logo (aksen kedua)
val NeuralVioletDark = Color(0xFF8C1046)  // marun logo
val NeuralAmber = Color(0xFFFFB454)
val NeuralGreen = Color(0xFF34D399)
val NeuralRed = Color(0xFFFF5C7A)

// Background & Surface Tokens (ungu malam)
val BackgroundDark = Color(0xFF210945)
val SurfaceDark = Color(0xFF2B0F58)
val SurfaceCardDark = Color(0xFF361567)
val SurfaceElevatedDark = Color(0xFF451D80)
val BorderSubtleDark = Color(0xFF5E3797)

// Light Palette (lavender lembut)
val BackgroundLight = Color(0xFFF8F3FF)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceCardLight = Color(0xFFF0E8FB)
val SurfaceElevatedLight = Color(0xFFE4D8F5)
val BorderSubtleLight = Color(0xFFCDBCE8)
