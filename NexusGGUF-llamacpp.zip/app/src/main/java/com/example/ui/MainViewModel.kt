package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.downloader.CuratedModelsList
import com.example.data.downloader.DownloadState
import com.example.data.downloader.ModelDownloader
import com.example.data.downloader.RemoteGgufModel
import com.example.data.gguf.GgufModelDetails
import com.example.data.gguf.GgufParser
import com.example.data.gguf.GgufSampleGenerator
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.local.ModelEntity
import com.example.engine.DeviceSpecs
import com.example.engine.DeviceTelemetry
import com.example.engine.GenerationEvent
import com.example.engine.GenerationMetrics
import com.example.engine.GenerationSettings
import com.example.engine.LocalInferenceEngine
import com.example.engine.TextToSpeechHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val modelDao = db.modelDao()
    private val chatDao = db.chatDao()

    private val parser = GgufParser(application)
    private val downloader = ModelDownloader(application)
    private val inferenceEngine = LocalInferenceEngine(application)
    private val ttsHelper = TextToSpeechHelper(application)

    // Models from database
    val localModels: StateFlow<List<ModelEntity>> = modelDao.getAllModels()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently active loaded GGUF model
    private val _activeModelDetails = MutableStateFlow<GgufModelDetails?>(null)
    val activeModelDetails: StateFlow<GgufModelDetails?> = _activeModelDetails.asStateFlow()

    // Model currently selected for inspection in Inspector tab
    private val _inspectedModelDetails = MutableStateFlow<GgufModelDetails?>(null)
    val inspectedModelDetails: StateFlow<GgufModelDetails?> = _inspectedModelDetails.asStateFlow()

    // Status pemuatan model (llama.cpp)
    private val _isLoadingModel = MutableStateFlow(false)
    val isLoadingModel: StateFlow<Boolean> = _isLoadingModel.asStateFlow()

    // Download state
    val downloadState: StateFlow<DownloadState> = downloader.downloadState

    // Chat sessions and messages
    private val _currentSessionId = MutableStateFlow<String?>(null)
    val currentSessionId: StateFlow<String?> = _currentSessionId.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessageEntity>> = _chatMessages.asStateFlow()

    // Live generation state
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingText = MutableStateFlow("")
    val streamingText: StateFlow<String> = _streamingText.asStateFlow()

    private val _liveMetrics = MutableStateFlow<GenerationMetrics?>(null)
    val liveMetrics: StateFlow<GenerationMetrics?> = _liveMetrics.asStateFlow()

    // Device telemetry
    private val _deviceSpecs = MutableStateFlow(DeviceTelemetry.getDeviceSpecs(application))
    val deviceSpecs: StateFlow<DeviceSpecs> = _deviceSpecs.asStateFlow()

    // Settings
    private val _settings = MutableStateFlow(GenerationSettings())
    val settings: StateFlow<GenerationSettings> = _settings.asStateFlow()

    // TTS
    val isSpeaking: StateFlow<Boolean> = ttsHelper.isSpeaking

    // Benchmark state
    private val _isBenchmarking = MutableStateFlow(false)
    val isBenchmarking: StateFlow<Boolean> = _isBenchmarking.asStateFlow()

    private val _benchmarkResult = MutableStateFlow<String?>(null)
    val benchmarkResult: StateFlow<String?> = _benchmarkResult.asStateFlow()

    init {
        initializeSampleAndDefaultSession()
        refreshDeviceSpecs()
    }

    private fun initializeSampleAndDefaultSession() {
        viewModelScope.launch(Dispatchers.IO) {
            // 1. Create or get bundled sample GGUF
            val sampleFile = GgufSampleGenerator.getOrGenerateSampleModel(getApplication())
            val sampleDetails = parser.parseFile(sampleFile)

            if (sampleDetails.isValid) {
                val sampleEntity = ModelEntity(
                    id = "sample-smollm-q4",
                    name = sampleDetails.modelName,
                    filename = sampleDetails.fileName,
                    pathOrUri = sampleFile.absolutePath,
                    architecture = sampleDetails.architecture,
                    parameterSize = sampleDetails.formattedParamCount,
                    quantization = sampleDetails.quantization,
                    contextLength = sampleDetails.contextLength,
                    fileSizeBytes = sampleFile.length(),
                    isBundled = true,
                    isFavorite = true
                )
                modelDao.insertOrUpdate(sampleEntity)

                // Model contoh hanya untuk Inspector (tidak punya bobot asli, tidak bisa dijalankan).
                _inspectedModelDetails.value = sampleDetails
            }

            // 2. Initialize default chat session
            val defaultSessionId = UUID.randomUUID().toString()
            _currentSessionId.value = defaultSessionId
            val defaultSession = ChatSessionEntity(
                id = defaultSessionId,
                title = "GGUF On-Device Session",
                modelId = "Nexus Local"
            )
            chatDao.insertSession(defaultSession)

            // Add welcome message (role "system" supaya tidak ikut masuk riwayat prompt)
            val welcomeMsg = ChatMessageEntity(
                sessionId = defaultSessionId,
                role = "system",
                content = "Selamat datang di **NexusGGUF**!\n\n" +
                        "• Mesin: **llama.cpp** berjalan langsung di ponsel ini, 100% offline\n" +
                        "• Buka tab **Models** → **Import .GGUF** untuk memilih file model dari penyimpanan ponsel\n" +
                        "• Untuk RAM 8 GB, model 1–4B parameter (Q4_K_M) paling nyaman",
                tokensCount = 0,
                generationTimeMs = 0,
                tokensPerSec = 0.0
            )
            chatDao.insertMessage(welcomeMsg)
            _chatMessages.value = listOf(welcomeMsg)
        }
    }

    fun refreshDeviceSpecs() {
        _deviceSpecs.value = DeviceTelemetry.getDeviceSpecs(getApplication())
    }

    fun loadModel(modelEntity: ModelEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(modelEntity.pathOrUri)
            val details = if (file.exists()) {
                parser.parseFile(file)
            } else {
                try {
                    parser.parseUri(Uri.parse(modelEntity.pathOrUri), modelEntity.name)
                } catch (e: Exception) {
                    null
                }
            }

            if (details != null && details.isValid) {
                if (activateModel(details)) {
                    modelDao.updateLastUsed(modelEntity.id, System.currentTimeMillis())
                }
            } else {
                postNote("⚠️ File model tidak bisa dibaca: ${details?.errorMessage ?: "URI tidak valid / izin hilang"}")
            }
        }
    }

    /** Muat model ke llama.cpp dan tandai sebagai aktif. Return true jika berhasil. */
    private suspend fun activateModel(details: GgufModelDetails): Boolean {
        _isLoadingModel.value = true
        try {
            val error = inferenceEngine.loadModel(details, _settings.value)
            _inspectedModelDetails.value = details
            return if (error == null) {
                _activeModelDetails.value = details
                postNote("✅ Model **${details.modelName}** (${details.quantization}, ${details.formattedFileSize}) siap dipakai.")
                true
            } else {
                _activeModelDetails.value = null
                postNote("⚠️ Gagal memuat **${details.modelName}**: $error")
                false
            }
        } finally {
            _isLoadingModel.value = false
        }
    }

    /** Pesan status di chat (role "system": tampil di UI, tidak masuk riwayat prompt). */
    private suspend fun postNote(text: String) {
        val sessionId = _currentSessionId.value ?: return
        val note = ChatMessageEntity(sessionId = sessionId, role = "system", content = text)
        _chatMessages.value = _chatMessages.value + note
        withContext(Dispatchers.IO) { chatDao.insertMessage(note) }
    }

    fun inspectModel(modelEntity: ModelEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(modelEntity.pathOrUri)
            val details = if (file.exists()) {
                parser.parseFile(file)
            } else {
                try {
                    parser.parseUri(Uri.parse(modelEntity.pathOrUri), modelEntity.name)
                } catch (e: Exception) {
                    null
                }
            }
            if (details != null) {
                _inspectedModelDetails.value = details
            }
        }
    }

    fun importGgufUri(uri: Uri, displayName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            // Simpan izin baca permanen agar model tetap bisa dibuka setelah aplikasi ditutup.
            try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            val details = parser.parseUri(uri, displayName)
            if (details.isValid) {
                val entity = ModelEntity(
                    name = details.modelName,
                    filename = details.fileName,
                    pathOrUri = uri.toString(),
                    architecture = details.architecture,
                    parameterSize = details.formattedParamCount,
                    quantization = details.quantization,
                    contextLength = details.contextLength,
                    fileSizeBytes = details.fileSize,
                    isBundled = false,
                    isFavorite = false
                )
                modelDao.insertOrUpdate(entity)
                activateModel(details)
            } else {
                postNote("⚠️ Bukan file GGUF yang valid: ${details.errorMessage ?: displayName}")
            }
        }
    }

    fun downloadCuratedModel(model: RemoteGgufModel) {
        viewModelScope.launch {
            val file = downloader.downloadModel(model)
            if (file != null && file.exists()) {
                val details = withContext(Dispatchers.IO) { parser.parseFile(file) }
                if (details.isValid) {
                    val entity = ModelEntity(
                        id = model.id,
                        name = details.modelName.ifBlank { model.name },
                        filename = file.name,
                        pathOrUri = file.absolutePath,
                        architecture = details.architecture,
                        parameterSize = details.formattedParamCount,
                        quantization = details.quantization,
                        contextLength = details.contextLength,
                        fileSizeBytes = file.length(),
                        isBundled = false,
                        isFavorite = true
                    )
                    withContext(Dispatchers.IO) {
                        modelDao.insertOrUpdate(entity)
                        activateModel(details)
                    }
                }
            }
        }
    }

    fun cancelDownload() {
        downloader.cancelDownload()
    }

    fun deleteModel(modelEntity: ModelEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            if (!modelEntity.isBundled) {
                val file = File(modelEntity.pathOrUri)
                if (file.exists()) file.delete()
            }
            modelDao.delete(modelEntity)
            if (_activeModelDetails.value?.filePath == modelEntity.pathOrUri) {
                inferenceEngine.unloadModel()
                _activeModelDetails.value = null
            }
        }
    }

    fun toggleFavorite(modelEntity: ModelEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            modelDao.updateFavorite(modelEntity.id, !modelEntity.isFavorite)
        }
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty() || _isGenerating.value) return

        val sessionId = _currentSessionId.value ?: return

        viewModelScope.launch {
            // 1. Add User Message
            val userMsg = ChatMessageEntity(
                sessionId = sessionId,
                role = "user",
                content = trimmed
            )
            _chatMessages.value = _chatMessages.value + userMsg
            withContext(Dispatchers.IO) {
                chatDao.insertMessage(userMsg)
            }

            // 2. Prepare Context & Format Prompt
            // Pesan terbaru (userMsg) sudah ada di daftar; riwayat = pesan sebelumnya saja.
            val history = _chatMessages.value
                .dropLast(1)
                .filter { it.role == "user" || it.role == "assistant" }
                .takeLast(6)
                .map { it.role to it.content }
            val formattedPrompt = withContext(Dispatchers.Default) {
                inferenceEngine.formatPrompt(
                    systemPrompt = _settings.value.systemPrompt,
                    conversationHistory = history,
                    newPrompt = trimmed,
                    template = _settings.value.templateOverride
                )
            }

            // 3. Start Streaming Generation
            _isGenerating.value = true
            _streamingText.value = ""
            _liveMetrics.value = null

            inferenceEngine.generateStreaming(formattedPrompt, _settings.value).collect { event ->
                when (event) {
                    is GenerationEvent.Token -> {
                        _streamingText.value = event.fullText
                        _liveMetrics.value = event.metrics
                    }
                    is GenerationEvent.Complete -> {
                        _isGenerating.value = false
                        _streamingText.value = ""
                        _liveMetrics.value = event.metrics

                        val aiMsg = ChatMessageEntity(
                            sessionId = sessionId,
                            role = "assistant",
                            content = event.fullText,
                            tokensCount = event.metrics.totalTokens,
                            generationTimeMs = event.metrics.elapsedMs,
                            tokensPerSec = event.metrics.tokensPerSecond
                        )
                        _chatMessages.value = _chatMessages.value + aiMsg
                        withContext(Dispatchers.IO) {
                            chatDao.insertMessage(aiMsg)
                        }
                    }
                    is GenerationEvent.Error -> {
                        _isGenerating.value = false
                        val errorMsg = ChatMessageEntity(
                            sessionId = sessionId,
                            role = "system",
                            content = "⚠️ ${event.message}"
                        )
                        _chatMessages.value = _chatMessages.value + errorMsg
                    }
                }
            }
        }
    }

    fun stopGeneration() {
        inferenceEngine.cancelGeneration()
    }

    fun clearChat() {
        viewModelScope.launch(Dispatchers.IO) {
            val sessionId = _currentSessionId.value ?: return@launch
            chatDao.deleteMessagesForSession(sessionId)
            _chatMessages.value = emptyList()
        }
    }

    fun speakMessage(text: String) {
        ttsHelper.speak(text)
    }

    fun stopSpeech() {
        ttsHelper.stop()
    }

    fun updateSettings(newSettings: GenerationSettings) {
        _settings.value = newSettings
    }

    fun runBenchmark() {
        val model = _activeModelDetails.value ?: return
        viewModelScope.launch {
            _isBenchmarking.value = true
            _benchmarkResult.value = null

            val testPrompt = "Explain how quantized GGUF neural weights optimize matrix multiplication on mobile CPUs."
            val startTime = System.currentTimeMillis()
            var tokensGenerated = 0
            var finalSpeed = 0.0

            inferenceEngine.generateStreaming(
                testPrompt,
                _settings.value.copy(maxTokens = 60)
            ).collect { event ->
                when (event) {
                    is GenerationEvent.Token -> {
                        tokensGenerated = event.metrics.totalTokens
                        finalSpeed = event.metrics.tokensPerSecond
                    }
                    is GenerationEvent.Complete -> {
                        val totalTime = System.currentTimeMillis() - startTime
                        val result = buildString {
                            append("Benchmark Completed Successfully!\n\n")
                            append("• Model: ${model.modelName}\n")
                            append("• Architecture: ${model.architecture}\n")
                            append("• Quantization: ${model.quantization}\n")
                            append("• CPU Cores Utilized: ${_settings.value.threads}\n")
                            append("• TTFT (Time To First Token): ${event.metrics.timeToFirstTokenMs} ms\n")
                            append("• Generation Speed: ${String.format("%.1f", finalSpeed)} tok/s\n")
                            append("• Total Generated: $tokensGenerated tokens in ${totalTime}ms\n")
                            append("• Peak Memory (PSS): ${String.format("%.1f", event.metrics.memoryUsageMb)} MB\n")
                            append("• Efficiency Rating: ${if (finalSpeed > 20) "⚡ Excellent (Real-time speed)" else "✓ Good (Solid Mobile Performance)"}")
                        }
                        _benchmarkResult.value = result
                        _isBenchmarking.value = false
                    }
                    is GenerationEvent.Error -> {
                        _benchmarkResult.value = "Benchmark failed: ${event.message}"
                        _isBenchmarking.value = false
                    }
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsHelper.shutdown()
        Thread { inferenceEngine.unloadModel() }.start()
    }
}
