package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = NeuralCyan,
    onPrimary = Color(0xFF002D2E),
    primaryContainer = Color(0xFF0B5A5D),
    onPrimaryContainer = Color(0xFFA6F5F7),

    secondary = NeuralViolet,
    onSecondary = Color.White,
    secondaryContainer = NeuralVioletDark,
    onSecondaryContainer = Color(0xFFFFD9E6),

    tertiary = NeuralAmber,
    onTertiary = Color(0xFF452B00),
    tertiaryContainer = Color(0xFF633F00),
    onTertiaryContainer = Color(0xFFFFDDB3),

    background = BackgroundDark,
    onBackground = Color(0xFFF3ECFF),

    surface = SurfaceDark,
    onSurface = Color(0xFFF3ECFF),
    surfaceVariant = SurfaceCardDark,
    onSurfaceVariant = Color(0xFFC5B4E3),

    outline = BorderSubtleDark,
    outlineVariant = Color(0xFF3A1B6E)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0B7C80),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFA6F5F7),
    onPrimaryContainer = Color(0xFF002021),

    secondary = Color(0xFFB0104F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFD9E6),
    onSecondaryContainer = Color(0xFF3F001A),

    tertiary = Color(0xFF825500),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDDB3),
    onTertiaryContainer = Color(0xFF291800),

    background = BackgroundLight,
    onBackground = Color(0xFF1B0B35),

    surface = SurfaceLight,
    onSurface = Color(0xFF1B0B35),
    surfaceVariant = SurfaceCardLight,
    onSurfaceVariant = Color(0xFF5A4A78),

    outline = BorderSubtleLight,
    outlineVariant = Color(0xFFE4D8F5)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to futuristic dark mode
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
