package com.example.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.GenerationSettings
import com.example.ui.MainViewModel
import com.example.ui.theme.NeuralCyan

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentSettings by viewModel.settings.collectAsState()

    var threads by remember(currentSettings) { mutableIntStateOf(currentSettings.threads) }
    var temperature by remember(currentSettings) { mutableFloatStateOf(currentSettings.temperature) }
    var topP by remember(currentSettings) { mutableFloatStateOf(currentSettings.topP) }
    var topK by remember(currentSettings) { mutableIntStateOf(currentSettings.topK) }
    var repeatPenalty by remember(currentSettings) { mutableFloatStateOf(currentSettings.repeatPenalty) }
    var maxTokens by remember(currentSettings) { mutableIntStateOf(currentSettings.maxTokens) }
    var templateOverride by remember(currentSettings) { mutableStateOf(currentSettings.templateOverride) }
    var systemPrompt by remember(currentSettings) { mutableStateOf(currentSettings.systemPrompt) }

    fun save() {
        viewModel.updateSettings(
            GenerationSettings(
                temperature = temperature,
                topP = topP,
                topK = topK,
                repeatPenalty = repeatPenalty,
                maxTokens = maxTokens,
                threads = threads,
                systemPrompt = systemPrompt,
                templateOverride = templateOverride
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 40.dp)
    ) {
        item {
            Column {
                Text(
                    text = "INFERENCE PARAMETERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeuralCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Runtime & Generation Tuning",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            // Hardware Execution Threads
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "CPU Inference Threads", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(text = "$threads Threads", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NeuralCyan)
                    }
                    Text(
                        text = "Number of CPU cores allocated for matrix multiplications.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = threads.toFloat(),
                        onValueChange = {
                            threads = it.toInt()
                            save()
                        },
                        valueRange = 1f..8f,
                        steps = 6,
                        colors = SliderDefaults.colors(thumbColor = NeuralCyan, activeTrackColor = NeuralCyan)
                    )
                }
            }
        }

        item {
            // Sampling Hyper-parameters
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Sampling Controls", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Temperature
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Temperature", style = MaterialTheme.typography.bodyMedium)
                        Text(text = String.format("%.2f", temperature), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = NeuralCyan)
                    }
                    Slider(
                        value = temperature,
                        onValueChange = {
                            temperature = it
                            save()
                        },
                        valueRange = 0.0f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = NeuralCyan, activeTrackColor = NeuralCyan)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Top-P
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Top-P (Nucleus)", style = MaterialTheme.typography.bodyMedium)
                        Text(text = String.format("%.2f", topP), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = NeuralCyan)
                    }
                    Slider(
                        value = topP,
                        onValueChange = {
                            topP = it
                            save()
                        },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(thumbColor = NeuralCyan, activeTrackColor = NeuralCyan)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Max Tokens
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Max Output Tokens", style = MaterialTheme.typography.bodyMedium)
                        Text(text = "$maxTokens tokens", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = NeuralCyan)
                    }
                    Slider(
                        value = maxTokens.toFloat(),
                        onValueChange = {
                            maxTokens = it.toInt()
                            save()
                        },
                        valueRange = 64f..1024f,
                        steps = 14,
                        colors = SliderDefaults.colors(thumbColor = NeuralCyan, activeTrackColor = NeuralCyan)
                    )
                }
            }
        }

        item {
            // Chat Template Selector
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Prompt Format / Chat Template", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Auto resolves template from GGUF tokenizer metadata, or select a manual template override.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val templates = listOf("Auto", "ChatML", "Llama3", "Mistral", "Raw")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(templates) { template ->
                            val isSelected = templateOverride == template
                            Button(
                                onClick = {
                                    templateOverride = template
                                    save()
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) NeuralCyan else MaterialTheme.colorScheme.surface,
                                    contentColor = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text(text = template, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }
        }

        item {
            // System Prompt Editor & Presets
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "System Prompt", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    val presets = listOf(
                        "Helpful Assistant" to "You are a helpful, brilliant, and concise local AI assistant running directly on an Android device via GGUF neural weights.",
                        "Coding Specialist" to "You are an expert software engineer. Provide concise, clean, working code snippets with minimal conversational filler.",
                        "Concise Q&A" to "Answer questions strictly in 1-2 direct sentences with accurate facts.",
                        "Private Local" to "You are an on-device privacy-first AI. Acknowledge queries concisely without external assumptions."
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(presets) { (title, promptText) ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier.padding(bottom = 8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        systemPrompt = promptText
                                        save()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.Transparent,
                                        contentColor = MaterialTheme.colorScheme.onSurface
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(text = title, fontSize = 10.sp)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = systemPrompt,
                        onValueChange = {
                            systemPrompt = it
                            save()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 5,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeuralCyan,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }
            }
        }
    }
}
