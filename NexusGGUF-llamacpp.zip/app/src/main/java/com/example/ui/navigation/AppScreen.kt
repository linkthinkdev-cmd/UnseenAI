package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppScreen(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    Chat("Chat", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
    Models("Models", Icons.Filled.Memory, Icons.Outlined.Memory),
    Inspector("Inspector", Icons.Filled.Search, Icons.Outlined.Search),
    Benchmark("Benchmark", Icons.Filled.Speed, Icons.Outlined.Speed),
    Settings("Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}
