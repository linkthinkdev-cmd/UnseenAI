package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "gguf_models")
data class ModelEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val filename: String,
    val pathOrUri: String,
    val architecture: String,
    val parameterSize: String,
    val quantization: String,
    val contextLength: Int,
    val fileSizeBytes: Long,
    val isBundled: Boolean = false,
    val isFavorite: Boolean = false,
    val lastUsedTimestamp: Long = System.currentTimeMillis(),
    val importedAt: Long = System.currentTimeMillis()
) {
    val formattedFileSize: String
        get() {
            val mb = fileSizeBytes / (1024.0 * 1024.0)
            return if (mb >= 1024) {
                String.format("%.2f GB", mb / 1024.0)
            } else {
                String.format("%.1f MB", mb)
            }
        }
}

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val modelId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val role: String, // "user", "assistant", "system"
    val content: String,
    val tokensCount: Int = 0,
    val generationTimeMs: Long = 0L,
    val tokensPerSec: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
)
