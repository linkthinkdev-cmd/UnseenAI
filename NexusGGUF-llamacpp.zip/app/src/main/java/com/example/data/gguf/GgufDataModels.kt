package com.example.data.gguf

/**
 * GGUF binary format constants and specifications.
 */
object GgufConstants {
    // Magic: "GGUF" in ASCII -> 0x46554747 (Little Endian: 0x47, 0x47, 0x55, 0x46)
    const val GGUF_MAGIC = 0x46554747
    const val GGUF_VERSION_2 = 2
    const val GGUF_VERSION_3 = 3

    // Value Types
    const val TYPE_UINT8 = 0
    const val TYPE_INT8 = 1
    const val TYPE_UINT16 = 2
    const val TYPE_INT16 = 3
    const val TYPE_UINT32 = 4
    const val TYPE_INT32 = 5
    const val TYPE_FLOAT32 = 6
    const val TYPE_BOOL = 7
    const val TYPE_STRING = 8
    const val TYPE_ARRAY = 9
    const val TYPE_UINT64 = 10
    const val TYPE_INT64 = 11
    const val TYPE_FLOAT64 = 12

    fun typeName(type: Int): String = when (type) {
        TYPE_UINT8 -> "UINT8"
        TYPE_INT8 -> "INT8"
        TYPE_UINT16 -> "UINT16"
        TYPE_INT16 -> "INT16"
        TYPE_UINT32 -> "UINT32"
        TYPE_INT32 -> "INT32"
        TYPE_FLOAT32 -> "FLOAT32"
        TYPE_BOOL -> "BOOL"
        TYPE_STRING -> "STRING"
        TYPE_ARRAY -> "ARRAY"
        TYPE_UINT64 -> "UINT64"
        TYPE_INT64 -> "INT64"
        TYPE_FLOAT64 -> "FLOAT64"
        else -> "UNKNOWN($type)"
    }
}

/**
 * GGML Tensor Quantization Types
 */
enum class GgmlType(val value: Int, val typeName: String, val bytesPerBlock: Int, val blockSize: Int) {
    F32(0, "F32", 4, 1),
    F16(1, "F16", 2, 1),
    Q4_0(2, "Q4_0", 18, 32),
    Q4_1(3, "Q4_1", 20, 32),
    Q5_0(6, "Q5_0", 22, 32),
    Q5_1(7, "Q5_1", 24, 32),
    Q8_0(8, "Q8_0", 34, 32),
    Q8_1(9, "Q8_1", 40, 32),
    Q2_K(10, "Q2_K", 8, 32),
    Q3_K(11, "Q3_K", 11, 32),
    Q4_K(12, "Q4_K", 144, 256),
    Q5_K(13, "Q5_K", 176, 256),
    Q6_K(14, "Q6_K", 210, 256),
    Q8_K(15, "Q8_K", 292, 256),
    IQ2_XXS(16, "IQ2_XXS", 66, 256),
    IQ2_XS(17, "IQ2_XS", 74, 256),
    IQ3_XXS(18, "IQ3_XXS", 98, 256),
    IQ1_S(19, "IQ1_S", 50, 256),
    IQ4_NL(20, "IQ4_NL", 144, 256),
    IQ3_S(21, "IQ3_S", 110, 256),
    IQ2_S(22, "IQ2_S", 82, 256),
    IQ4_XS(23, "IQ4_XS", 136, 256),
    I8(24, "I8", 1, 1),
    I16(25, "I16", 2, 1),
    I32(26, "I32", 4, 1),
    I64(27, "I64", 8, 1),
    F64(28, "F64", 8, 1),
    IQ1_M(29, "IQ1_M", 56, 256),
    BF16(30, "BF16", 2, 1),
    UNKNOWN(-1, "UNKNOWN", 4, 1);

    companion object {
        fun fromValue(value: Int): GgmlType {
            return entries.find { it.value == value } ?: UNKNOWN
        }
    }
}

/**
 * Parsed GGUF Tensor Information
 */
data class GgufTensorInfo(
    val name: String,
    val dimensions: List<Long>,
    val type: GgmlType,
    val offset: Long,
    val estimatedBytes: Long = 0L
) {
    val shapeString: String
        get() = dimensions.joinToString(" × ")
}

/**
 * Key-Value Pair in GGUF metadata
 */
data class GgufMetadataEntry(
    val key: String,
    val type: Int,
    val value: Any
) {
    val displayValue: String
        get() = when (value) {
            is List<*> -> "Array[${value.size} items]"
            is ByteArray -> "Bytes[${value.size}]"
            else -> value.toString()
        }
}

/**
 * Complete Parsed GGUF Model Details
 */
data class GgufModelDetails(
    val fileName: String,
    val filePath: String,
    val fileSize: Long,
    val version: Int,
    val tensorCount: Long,
    val metadataKvCount: Long,
    val architecture: String,
    val modelName: String,
    val author: String?,
    val quantization: String,
    val contextLength: Int,
    val embeddingLength: Int,
    val blockCount: Int,
    val headCount: Int,
    val headCountKv: Int,
    val feedForwardLength: Int,
    val vocabSize: Int,
    val chatTemplate: String?,
    val bosTokenId: Int?,
    val eosTokenId: Int?,
    val sampleTokens: List<String>,
    val metadataList: List<GgufMetadataEntry>,
    val tensorList: List<GgufTensorInfo>,
    val estimatedParamCount: Long,
    val isValid: Boolean = true,
    val errorMessage: String? = null
) {
    val formattedFileSize: String
        get() {
            val mb = fileSize / (1024.0 * 1024.0)
            return if (mb >= 1024) {
                String.format("%.2f GB", mb / 1024.0)
            } else {
                String.format("%.1f MB", mb)
            }
        }

    val formattedParamCount: String
        get() = when {
            estimatedParamCount >= 1_000_000_000 -> String.format("%.2fB", estimatedParamCount / 1_000_000_000.0)
            estimatedParamCount >= 1_000_000 -> String.format("%.1fM", estimatedParamCount / 1_000_000.0)
            estimatedParamCount > 0 -> "$estimatedParamCount"
            else -> "Unknown"
        }
}
