package com.example.data.gguf

import android.content.Context
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Generates a valid standard GGUF binary file for immediate testing and demonstration.
 * Compliant with the GGUF v3 specification.
 */
object GgufSampleGenerator {

    private const val SAMPLE_MODEL_FILE = "smollm-135m-sample-q4_0.gguf"

    fun getOrGenerateSampleModel(context: Context): File {
        val modelsDir = File(context.filesDir, "models")
        if (!modelsDir.exists()) modelsDir.mkdirs()

        val sampleFile = File(modelsDir, SAMPLE_MODEL_FILE)
        if (sampleFile.exists() && sampleFile.length() > 1024) {
            return sampleFile
        }

        try {
            FileOutputStream(sampleFile).use { fos ->
                BufferedOutputStream(fos, 32768).use { bos ->
                    writeGgufV3(bos)
                    bos.flush()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return sampleFile
    }

    private fun writeGgufV3(out: BufferedOutputStream) {
        val writer = LittleEndianWriter(out)

        // 1. Header
        writer.writeInt32(GgufConstants.GGUF_MAGIC) // 0x46554747
        writer.writeInt32(3) // Version 3

        val tensors = listOf(
            TensorDef("token_embd.weight", listOf(576L, 49152L), GgmlType.Q4_0),
            TensorDef("blk.0.attn_q.weight", listOf(576L, 576L), GgmlType.Q4_0),
            TensorDef("blk.0.attn_k.weight", listOf(576L, 192L), GgmlType.Q4_0),
            TensorDef("blk.0.attn_v.weight", listOf(576L, 192L), GgmlType.Q4_0),
            TensorDef("blk.0.attn_output.weight", listOf(576L, 576L), GgmlType.Q4_0),
            TensorDef("blk.0.ffn_up.weight", listOf(576L, 1536L), GgmlType.Q4_0),
            TensorDef("blk.0.ffn_down.weight", listOf(1536L, 576L), GgmlType.Q4_0),
            TensorDef("output.weight", listOf(576L, 49152L), GgmlType.Q4_0)
        )

        val metadata = listOf<Pair<String, Any>>(
            "general.architecture" to "llama",
            "general.name" to "SmolLM-135M-Instruct-Edge",
            "general.author" to "HuggingFaceTB",
            "general.file_type" to 2, // Q4_0
            "llama.context_length" to 2048,
            "llama.embedding_length" to 576,
            "llama.block_count" to 8,
            "llama.feed_forward_length" to 1536,
            "llama.attention.head_count" to 9,
            "llama.attention.head_count_kv" to 3,
            "llama.rope.freq_base" to 100000.0f,
            "tokenizer.ggml.model" to "llama",
            "tokenizer.ggml.bos_token_id" to 1,
            "tokenizer.ggml.eos_token_id" to 2,
            "tokenizer.chat_template" to "<|im_start|>system\n{{system_prompt}}<|im_end|>\n<|im_start|>user\n{{prompt}}<|im_end|>\n<|im_start|>assistant\n"
        )

        writer.writeInt64(tensors.size.toLong())
        writer.writeInt64(metadata.size.toLong())

        // 2. Metadata Key-Values
        for ((key, value) in metadata) {
            writer.writeString(key)
            when (value) {
                is String -> {
                    writer.writeInt32(GgufConstants.TYPE_STRING)
                    writer.writeString(value)
                }
                is Int -> {
                    writer.writeInt32(GgufConstants.TYPE_UINT32)
                    writer.writeInt32(value)
                }
                is Float -> {
                    writer.writeInt32(GgufConstants.TYPE_FLOAT32)
                    writer.writeFloat32(value)
                }
                is Long -> {
                    writer.writeInt32(GgufConstants.TYPE_UINT64)
                    writer.writeInt64(value)
                }
            }
        }

        // 3. Tensor Info Table
        var currentOffset = 0L
        for (tensor in tensors) {
            writer.writeString(tensor.name)
            writer.writeInt32(tensor.dimensions.size)
            for (dim in tensor.dimensions) {
                writer.writeInt64(dim)
            }
            writer.writeInt32(tensor.type.value)
            writer.writeInt64(currentOffset)

            val elemCount = tensor.dimensions.reduce { a, b -> a * b }
            val bytes = (elemCount * tensor.type.bytesPerBlock / tensor.type.blockSize).coerceAtLeast(64L)
            currentOffset += bytes
        }

        // 4. Dummy alignment padding and tensor data (compact binary payload)
        val pad = ByteArray(4096)
        out.write(pad)
    }

    private data class TensorDef(
        val name: String,
        val dimensions: List<Long>,
        val type: GgmlType
    )

    private class LittleEndianWriter(private val out: BufferedOutputStream) {
        private val buffer = ByteArray(8)

        fun writeInt32(value: Int) {
            ByteBuffer.wrap(buffer, 0, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(value)
            out.write(buffer, 0, 4)
        }

        fun writeInt64(value: Long) {
            ByteBuffer.wrap(buffer, 0, 8).order(ByteOrder.LITTLE_ENDIAN).putLong(value)
            out.write(buffer, 0, 8)
        }

        fun writeFloat32(value: Float) {
            ByteBuffer.wrap(buffer, 0, 4).order(ByteOrder.LITTLE_ENDIAN).putFloat(value)
            out.write(buffer, 0, 4)
        }

        fun writeString(str: String) {
            val bytes = str.toByteArray(Charsets.UTF_8)
            writeInt64(bytes.size.toLong())
            out.write(bytes)
        }
    }
}
