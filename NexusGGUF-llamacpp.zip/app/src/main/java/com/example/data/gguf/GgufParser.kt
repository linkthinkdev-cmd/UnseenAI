package com.example.data.gguf

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Binary parser for GGUF (GPT-Generated Unified Format) v2 and v3 files.
 * Reads headers, key-value metadata pairs, tensor info tables, and architecture metadata.
 */
class GgufParser(private val context: Context) {

    fun parseUri(uri: Uri, displayName: String = "Imported Model"): GgufModelDetails {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: return createErrorDetails(displayName, uri.toString(), 0L, "Cannot open stream for URI")
        val size = try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: 0L
        } catch (e: Exception) {
            0L
        }
        return inputStream.use { stream ->
            parseStream(stream, displayName, uri.toString(), size)
        }
    }

    fun parseFile(file: File): GgufModelDetails {
        if (!file.exists()) {
            return createErrorDetails(file.name, file.absolutePath, 0L, "File does not exist")
        }
        val size = file.length()
        return file.inputStream().use { stream ->
            parseStream(stream, file.name, file.absolutePath, size)
        }
    }

    fun parseStream(
        rawStream: InputStream,
        fileName: String,
        filePath: String,
        fileSize: Long
    ): GgufModelDetails {
        val stream = BufferedInputStream(rawStream, 65536)
        val reader = LittleEndianReader(stream)

        try {
            // 1. Magic check (4 bytes)
            val magic = reader.readInt32()
            if (magic != GgufConstants.GGUF_MAGIC) {
                return createErrorDetails(
                    fileName, filePath, fileSize,
                    "Invalid GGUF magic bytes: 0x${Integer.toHexString(magic).uppercase()} (Expected: 0x46554747 'GGUF')"
                )
            }

            // 2. Version check (uint32)
            val version = reader.readInt32()
            if (version < 1 || version > 3) {
                return createErrorDetails(
                    fileName, filePath, fileSize,
                    "Unsupported GGUF version: $version (Supported: v2, v3)"
                )
            }

            // 3. Tensor count (uint64) and Metadata KV count (uint64)
            val tensorCount = reader.readInt64()
            val metadataKvCount = reader.readInt64()

            // 4. Read Metadata KV Pairs
            val metadataMap = mutableMapOf<String, Any>()
            val metadataEntries = mutableListOf<GgufMetadataEntry>()

            val safeKvCount = metadataKvCount.coerceAtMost(2000L).toInt()
            for (i in 0 until safeKvCount) {
                val key = reader.readString()
                val valType = reader.readInt32()
                val value = reader.readValue(valType)
                metadataMap[key] = value
                metadataEntries.add(GgufMetadataEntry(key, valType, value))
            }

            // 5. Read Tensor Info Table
            val tensors = mutableListOf<GgufTensorInfo>()
            val safeTensorCount = tensorCount.coerceAtMost(2000L).toInt()

            var totalEstimatedWeightBytes = 0L

            for (i in 0 until safeTensorCount) {
                val tensorName = reader.readString()
                val nDimensions = reader.readInt32()
                val dimensions = mutableListOf<Long>()
                var elementsCount = 1L
                for (d in 0 until nDimensions) {
                    val dim = reader.readInt64()
                    dimensions.add(dim)
                    elementsCount *= dim.coerceAtLeast(1L)
                }
                val rawType = reader.readInt32()
                val tensorType = GgmlType.fromValue(rawType)
                val offset = reader.readInt64()

                val bytesPerElement = (tensorType.bytesPerBlock.toDouble() / tensorType.blockSize.toDouble())
                val estimatedBytes = (elementsCount * bytesPerElement).toLong()
                totalEstimatedWeightBytes += estimatedBytes

                tensors.add(
                    GgufTensorInfo(
                        name = tensorName,
                        dimensions = dimensions,
                        type = tensorType,
                        offset = offset,
                        estimatedBytes = estimatedBytes
                    )
                )
            }

            // 6. Extract high-level architecture details
            val arch = (metadataMap["general.architecture"] as? String) ?: "llama"
            val modelName = (metadataMap["general.name"] as? String)
                ?: (metadataMap["$arch.name"] as? String)
                ?: fileName.removeSuffix(".gguf").replace("-", " ")
            val author = metadataMap["general.author"] as? String
            val fileTypeInt = (metadataMap["general.file_type"] as? Number)?.toInt() ?: -1
            val quantString = mapFileTypeToQuantName(fileTypeInt, tensors)

            val contextLength = (metadataMap["$arch.context_length"] as? Number)?.toInt()
                ?: (metadataMap["llama.context_length"] as? Number)?.toInt()
                ?: 2048

            val embeddingLength = (metadataMap["$arch.embedding_length"] as? Number)?.toInt()
                ?: (metadataMap["llama.embedding_length"] as? Number)?.toInt()
                ?: 2048

            val blockCount = (metadataMap["$arch.block_count"] as? Number)?.toInt()
                ?: (metadataMap["llama.block_count"] as? Number)?.toInt()
                ?: tensors.count { it.name.contains(".attn_q.") || it.name.contains(".attn_k.") }
                    .takeIf { it > 0 } ?: 16

            val headCount = (metadataMap["$arch.attention.head_count"] as? Number)?.toInt() ?: 16
            val headCountKv = (metadataMap["$arch.attention.head_count_kv"] as? Number)?.toInt() ?: headCount
            val feedForwardLength = (metadataMap["$arch.feed_forward_length"] as? Number)?.toInt() ?: (embeddingLength * 4)

            val chatTemplate = metadataMap["tokenizer.chat_template"] as? String
            val bosTokenId = (metadataMap["tokenizer.ggml.bos_token_id"] as? Number)?.toInt()
            val eosTokenId = (metadataMap["tokenizer.ggml.eos_token_id"] as? Number)?.toInt()

            @Suppress("UNCHECKED_CAST")
            val tokenList = metadataMap["tokenizer.ggml.tokens"] as? List<String> ?: emptyList()
            val vocabSize = tokenList.size.takeIf { it > 0 }
                ?: (metadataMap["tokenizer.ggml.token_type"] as? List<*>)?.size
                ?: 32000

            val sampleTokens = tokenList.take(60)

            // Estimate parameter count from tensors or blocks
            val estimatedParamCount = if (tensors.isNotEmpty()) {
                tensors.sumOf { t -> t.dimensions.reduceOrNull { acc, d -> acc * d } ?: 0L }
            } else {
                estimateParamsFromLayers(embeddingLength, blockCount, vocabSize)
            }

            return GgufModelDetails(
                fileName = fileName,
                filePath = filePath,
                fileSize = if (fileSize > 0) fileSize else totalEstimatedWeightBytes,
                version = version,
                tensorCount = tensorCount,
                metadataKvCount = metadataKvCount,
                architecture = arch,
                modelName = modelName,
                author = author,
                quantization = quantString,
                contextLength = contextLength,
                embeddingLength = embeddingLength,
                blockCount = blockCount,
                headCount = headCount,
                headCountKv = headCountKv,
                feedForwardLength = feedForwardLength,
                vocabSize = vocabSize,
                chatTemplate = chatTemplate,
                bosTokenId = bosTokenId,
                eosTokenId = eosTokenId,
                sampleTokens = sampleTokens,
                metadataList = metadataEntries,
                tensorList = tensors,
                estimatedParamCount = estimatedParamCount,
                isValid = true
            )
        } catch (e: Exception) {
            return createErrorDetails(fileName, filePath, fileSize, "Error parsing GGUF: ${e.message}")
        }
    }

    private fun mapFileTypeToQuantName(fileType: Int, tensors: List<GgufTensorInfo>): String {
        return when (fileType) {
            0 -> "F32"
            1 -> "F16"
            2 -> "Q4_0"
            3 -> "Q4_1"
            7 -> "Q8_0"
            8 -> "Q5_0"
            9 -> "Q5_1"
            10 -> "Q2_K"
            11 -> "Q3_K_S"
            12 -> "Q3_K_M"
            13 -> "Q3_K_L"
            14 -> "Q4_K_S"
            15 -> "Q4_K_M"
            16 -> "Q5_K_S"
            17 -> "Q5_K_M"
            18 -> "Q6_K"
            19 -> "IQ2_XXS"
            20 -> "IQ2_XS"
            21 -> "Q2_K_S"
            22 -> "IQ3_XS"
            23 -> "IQ3_XXS"
            24 -> "IQ1_S"
            25 -> "IQ4_NL"
            26 -> "IQ3_S"
            27 -> "IQ3_M"
            28 -> "IQ2_S"
            29 -> "IQ2_M"
            30 -> "IQ4_XS"
            31 -> "IQ1_M"
            32 -> "BF16"
            else -> {
                // If file_type not in KV, deduce from most common tensor type
                val commonType = tensors.groupBy { it.type }.maxByOrNull { it.value.size }?.key
                commonType?.typeName ?: "Q4_K_M"
            }
        }
    }

    private fun estimateParamsFromLayers(embedDim: Int, layers: Int, vocab: Int): Long {
        val embedParams = 2L * vocab * embedDim
        val layerParams = layers.toLong() * (4L * embedDim * embedDim + 3L * embedDim * embedDim * 4)
        return (embedParams + layerParams).coerceAtLeast(100_000_000L)
    }

    private fun createErrorDetails(
        name: String,
        path: String,
        size: Long,
        error: String
    ): GgufModelDetails {
        return GgufModelDetails(
            fileName = name,
            filePath = path,
            fileSize = size,
            version = 0,
            tensorCount = 0,
            metadataKvCount = 0,
            architecture = "Unknown",
            modelName = name,
            author = null,
            quantization = "Unknown",
            contextLength = 0,
            embeddingLength = 0,
            blockCount = 0,
            headCount = 0,
            headCountKv = 0,
            feedForwardLength = 0,
            vocabSize = 0,
            chatTemplate = null,
            bosTokenId = null,
            eosTokenId = null,
            sampleTokens = emptyList(),
            metadataList = emptyList(),
            tensorList = emptyList(),
            estimatedParamCount = 0,
            isValid = false,
            errorMessage = error
        )
    }

    /**
     * Helper to read little-endian primitives from an input stream
     */
    private class LittleEndianReader(private val stream: InputStream) {
        private val buffer = ByteArray(8)

        fun readInt8(): Byte {
            val b = stream.read()
            if (b == -1) throw IllegalStateException("Unexpected EOF")
            return b.toByte()
        }

        fun readInt16(): Short {
            readFully(buffer, 0, 2)
            return ByteBuffer.wrap(buffer, 0, 2).order(ByteOrder.LITTLE_ENDIAN).short
        }

        fun readInt32(): Int {
            readFully(buffer, 0, 4)
            return ByteBuffer.wrap(buffer, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
        }

        fun readInt64(): Long {
            readFully(buffer, 0, 8)
            return ByteBuffer.wrap(buffer, 0, 8).order(ByteOrder.LITTLE_ENDIAN).long
        }

        fun readFloat32(): Float {
            readFully(buffer, 0, 4)
            return ByteBuffer.wrap(buffer, 0, 4).order(ByteOrder.LITTLE_ENDIAN).float
        }

        fun readFloat64(): Double {
            readFully(buffer, 0, 8)
            return ByteBuffer.wrap(buffer, 0, 8).order(ByteOrder.LITTLE_ENDIAN).double
        }

        fun readBool(): Boolean {
            return readInt8() != 0.toByte()
        }

        fun readString(): String {
            val len = readInt64()
            if (len < 0 || len > 10_000_000) {
                throw IllegalStateException("String length out of bounds: $len")
            }
            val strBytes = ByteArray(len.toInt())
            readFully(strBytes, 0, strBytes.size)
            return String(strBytes, Charsets.UTF_8)
        }

        fun readValue(type: Int): Any {
            return when (type) {
                GgufConstants.TYPE_UINT8, GgufConstants.TYPE_INT8 -> readInt8().toInt()
                GgufConstants.TYPE_UINT16, GgufConstants.TYPE_INT16 -> readInt16().toInt()
                GgufConstants.TYPE_UINT32, GgufConstants.TYPE_INT32 -> readInt32()
                GgufConstants.TYPE_UINT64, GgufConstants.TYPE_INT64 -> readInt64()
                GgufConstants.TYPE_FLOAT32 -> readFloat32()
                GgufConstants.TYPE_FLOAT64 -> readFloat64()
                GgufConstants.TYPE_BOOL -> readBool()
                GgufConstants.TYPE_STRING -> readString()
                GgufConstants.TYPE_ARRAY -> {
                    val itemType = readInt32()
                    val arrayLen = readInt64()
                    val safeLen = arrayLen.coerceAtMost(200L).toInt()
                    val list = mutableListOf<Any>()
                    for (i in 0 until safeLen) {
                        list.add(readValue(itemType))
                    }
                    // Skip remaining items if array was larger than sample limit
                    if (arrayLen > safeLen) {
                        val remaining = arrayLen - safeLen
                        for (i in 0 until remaining) {
                            skipValue(itemType)
                        }
                    }
                    list
                }
                else -> "UnknownType($type)"
            }
        }

        private fun skipValue(type: Int) {
            when (type) {
                GgufConstants.TYPE_UINT8, GgufConstants.TYPE_INT8 -> readInt8()
                GgufConstants.TYPE_UINT16, GgufConstants.TYPE_INT16 -> readInt16()
                GgufConstants.TYPE_UINT32, GgufConstants.TYPE_INT32, GgufConstants.TYPE_FLOAT32 -> readInt32()
                GgufConstants.TYPE_UINT64, GgufConstants.TYPE_INT64, GgufConstants.TYPE_FLOAT64 -> readInt64()
                GgufConstants.TYPE_BOOL -> readInt8()
                GgufConstants.TYPE_STRING -> {
                    val len = readInt64()
                    skipBytes(len)
                }
                GgufConstants.TYPE_ARRAY -> {
                    val itemType = readInt32()
                    val count = readInt64()
                    for (i in 0 until count) {
                        skipValue(itemType)
                    }
                }
            }
        }

        private fun skipBytes(count: Long) {
            var remaining = count
            while (remaining > 0) {
                val skipped = stream.skip(remaining)
                if (skipped <= 0) {
                    if (stream.read() == -1) break
                    remaining -= 1
                } else {
                    remaining -= skipped
                }
            }
        }

        private fun readFully(b: ByteArray, off: Int, len: Int) {
            var n = 0
            while (n < len) {
                val count = stream.read(b, off + n, len - n)
                if (count < 0) throw IllegalStateException("End of stream reached prematurely (read $n of $len bytes)")
                n += count
            }
        }
    }
}
