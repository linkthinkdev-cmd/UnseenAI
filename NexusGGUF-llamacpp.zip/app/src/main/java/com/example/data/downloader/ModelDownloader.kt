package com.example.data.downloader

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class DownloadState {
    object Idle : DownloadState()
    data class Downloading(
        val modelId: String,
        val progressPercent: Int,
        val downloadedBytes: Long,
        val totalBytes: Long,
        val speedMbPerSec: Double
    ) : DownloadState()
    data class Completed(val modelId: String, val file: File) : DownloadState()
    data class Error(val modelId: String, val message: String) : DownloadState()
}

class ModelDownloader(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

    @Volatile
    private var isCancelled = false

    fun cancelDownload() {
        isCancelled = true
    }

    suspend fun downloadModel(model: RemoteGgufModel): File? = withContext(Dispatchers.IO) {
        isCancelled = false
        val modelsDir = File(context.filesDir, "models").apply { if (!exists()) mkdirs() }
        val targetFile = File(modelsDir, model.filename)
        val tempFile = File(modelsDir, "${model.filename}.tmp")

        _downloadState.value = DownloadState.Downloading(
            modelId = model.id,
            progressPercent = 0,
            downloadedBytes = 0L,
            totalBytes = model.fileSizeBytes,
            speedMbPerSec = 0.0
        )

        try {
            val request = Request.Builder()
                .url(model.downloadUrl)
                .header("User-Agent", "NexusGGUF-Android/1.0")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                _downloadState.value = DownloadState.Error(
                    model.id,
                    "HTTP ${response.code}: ${response.message}"
                )
                return@withContext null
            }

            val body = response.body ?: throw IOException("Empty response body")
            val totalLength = if (body.contentLength() > 0) body.contentLength() else model.fileSizeBytes

            var downloadedBytes = 0L
            val buffer = ByteArray(65536)
            var lastUpdateTime = System.currentTimeMillis()
            var bytesSinceLastUpdate = 0L
            var currentSpeed = 0.0

            body.byteStream().use { input ->
                FileOutputStream(tempFile).use { output ->
                    while (true) {
                        if (isCancelled) {
                            tempFile.delete()
                            _downloadState.value = DownloadState.Idle
                            return@withContext null
                        }
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        downloadedBytes += read
                        bytesSinceLastUpdate += read

                        val now = System.currentTimeMillis()
                        val diff = now - lastUpdateTime
                        if (diff >= 400) {
                            currentSpeed = (bytesSinceLastUpdate.toDouble() / (diff / 1000.0)) / (1024.0 * 1024.0)
                            val percent = if (totalLength > 0) ((downloadedBytes * 100) / totalLength).toInt() else 0
                            _downloadState.value = DownloadState.Downloading(
                                modelId = model.id,
                                progressPercent = percent.coerceIn(0, 100),
                                downloadedBytes = downloadedBytes,
                                totalBytes = totalLength,
                                speedMbPerSec = currentSpeed
                            )
                            lastUpdateTime = now
                            bytesSinceLastUpdate = 0L
                        }
                    }
                    output.flush()
                }
            }

            if (tempFile.renameTo(targetFile)) {
                _downloadState.value = DownloadState.Completed(model.id, targetFile)
                return@withContext targetFile
            } else {
                _downloadState.value = DownloadState.Error(model.id, "Failed to rename completed file")
                return@withContext null
            }
        } catch (e: Exception) {
            tempFile.delete()
            _downloadState.value = DownloadState.Error(model.id, e.message ?: "Download failed")
            return@withContext null
        }
    }

    fun resetState() {
        _downloadState.value = DownloadState.Idle
    }
}
