package com.example.data.downloader

data class RemoteGgufModel(
    val id: String,
    val name: String,
    val repo: String,
    val filename: String,
    val architecture: String,
    val paramSize: String,
    val quant: String,
    val fileSizeFormatted: String,
    val fileSizeBytes: Long,
    val recommendedRamGb: Int,
    val description: String,
    val downloadUrl: String,
    val tags: List<String>
)

object CuratedModelsList {
    val models = listOf(
        RemoteGgufModel(
            id = "smollm2-135m-q4km",
            name = "SmolLM2 135M Instruct",
            repo = "HuggingFaceTB/SmolLM2-135M-Instruct-GGUF",
            filename = "smollm2-135m-instruct-q4_k_m.gguf",
            architecture = "llama",
            paramSize = "135M",
            quant = "Q4_K_M",
            fileSizeFormatted = "89 MB",
            fileSizeBytes = 93_000_000L,
            recommendedRamGb = 1,
            description = "Ultra-fast micro model designed by Hugging Face for lightweight on-device edge computing and instant testing.",
            downloadUrl = "https://huggingface.co/HuggingFaceTB/SmolLM2-135M-Instruct-GGUF/resolve/main/smollm2-135m-instruct-q4_k_m.gguf",
            tags = listOf("Fast", "Edge", "Low RAM", "HuggingFace")
        ),
        RemoteGgufModel(
            id = "smollm2-360m-q4km",
            name = "SmolLM2 360M Instruct",
            repo = "HuggingFaceTB/SmolLM2-360M-Instruct-GGUF",
            filename = "smollm2-360m-instruct-q4_k_m.gguf",
            architecture = "llama",
            paramSize = "360M",
            quant = "Q4_K_M",
            fileSizeFormatted = "228 MB",
            fileSizeBytes = 239_000_000L,
            recommendedRamGb = 2,
            description = "Well-balanced sub-billion model with sharp conversational logic and rapid token generation.",
            downloadUrl = "https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct-GGUF/resolve/main/smollm2-360m-instruct-q4_k_m.gguf",
            tags = listOf("Popular", "Chat", "Mobile", "HuggingFace")
        ),
        RemoteGgufModel(
            id = "qwen25-05b-q4km",
            name = "Qwen 2.5 0.5B Instruct",
            repo = "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
            filename = "qwen2.5-0.5b-instruct-q4_k_m.gguf",
            architecture = "qwen2",
            paramSize = "0.5B",
            quant = "Q4_K_M",
            fileSizeFormatted = "392 MB",
            fileSizeBytes = 411_000_000L,
            recommendedRamGb = 3,
            description = "State-of-the-art multilingual compact model from Alibaba Cloud with superior code & math reasoning capabilities.",
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
            tags = listOf("Reasoning", "Multilingual", "Coding", "Alibaba")
        ),
        RemoteGgufModel(
            id = "tinyllama-11b-q4km",
            name = "TinyLlama 1.1B Chat v1.0",
            repo = "TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF",
            filename = "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
            architecture = "llama",
            paramSize = "1.1B",
            quant = "Q4_K_M",
            fileSizeFormatted = "669 MB",
            fileSizeBytes = 701_000_000L,
            recommendedRamGb = 4,
            description = "Trained on 3 trillion tokens. The golden standard for 1B class local mobile benchmarks and conversation.",
            downloadUrl = "https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
            tags = listOf("Standard", "Benchmark", "Compact", "OpenSource")
        ),
        RemoteGgufModel(
            id = "llama32-1b-q4km",
            name = "Llama 3.2 1B Instruct",
            repo = "bartowski/Llama-3.2-1B-Instruct-GGUF",
            filename = "Llama-3.2-1B-Instruct-Q4_K_M.gguf",
            architecture = "llama",
            paramSize = "1.23B",
            quant = "Q4_K_M",
            fileSizeFormatted = "750 MB",
            fileSizeBytes = 786_000_000L,
            recommendedRamGb = 4,
            description = "Meta's flagship mobile architecture with 128k context support and aligned instruction following.",
            downloadUrl = "https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf",
            tags = listOf("Meta", "Llama3", "High Quality", "Edge")
        )
    )
}
