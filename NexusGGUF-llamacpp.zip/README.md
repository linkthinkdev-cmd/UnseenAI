# NexusGGUF — chat LLM GGUF offline di Android (llama.cpp)

Aplikasi ini menjalankan model `.gguf` langsung di ponsel dengan **llama.cpp** (CPU arm64), tanpa internet.

## Memakai
1. Pasang APK, buka tab **Models** → **Import .GGUF**, pilih file model dari penyimpanan ponsel.
2. Buka tab **Chat** dan mulai bercakap. Internet hanya dipakai bila kamu mengunduh model dari tab Models.
3. Untuk RAM 8 GB: model 1–4B parameter kuantisasi Q4_K_M paling nyaman (±1–2,5 GB).
   Model 7B Q4 (±4,4 GB) bisa dimuat tetapi lambat dan rawan dimatikan sistem.

## Membangun APK lewat GitHub
Unggah zip ini utuh ke repo bersama `.github/workflows/build-apk.yml`. Workflow akan mengekstrak zip,
mengambil llama.cpp (tag `b11719`), lalu membangun APK dan menaruhnya di tab **Releases**.

## Membangun lokal (Android Studio)
```
git clone --depth 1 --branch b11719 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
```
Lalu pasang NDK `27.2.12479018` dan CMake `3.22.1` dari SDK Manager, dan build seperti biasa.

## Struktur native
- `app/src/main/cpp/CMakeLists.txt` — membangun llama.cpp + jembatan JNI
- `app/src/main/cpp/nexus_llama.cpp` — JNI (muat model dari file descriptor, chat template, sampling, streaming token)
- `app/src/main/java/com/example/engine/LlamaBridge.kt` — deklarasi `external fun`
- `app/src/main/java/com/example/engine/InferenceEngine.kt` — mesin inferensi (Flow token)
