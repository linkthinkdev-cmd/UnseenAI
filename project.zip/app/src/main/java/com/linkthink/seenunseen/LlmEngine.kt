package com.linkthink.seenunseen

import android.content.Context
import kotlinx.coroutines.flow.Flow
import java.io.File

/** Fasad: memilih mesin sesuai jenis model yang terpasang (.litertlm atau .gguf). */
class LlmEngine(private val context: Context) {

    private val litert = LiteRtEngine()
    private val llama = LlamaEngine()

    @Volatile
    private var active: ChatEngine? = null

    private val minSize = 50L * 1024 * 1024

    val modelDir: File
        get() = File(context.filesDir, "models")

    fun fileFor(kind: ModelKind): File = File(modelDir, kind.fileName)

    fun installedKind(): ModelKind? =
        ModelKind.values().firstOrNull { fileFor(it).let { f -> f.exists() && f.length() > minSize } }

    fun removeModels() {
        ModelKind.values().forEach { fileFor(it).delete() }
    }

    suspend fun load(): ModelKind {
        unload()
        val kind = installedKind() ?: throw IllegalStateException("Belum ada model terpasang")
        val engine: ChatEngine = if (kind == ModelKind.GGUF) llama else litert
        engine.load(fileFor(kind))
        active = engine
        return kind
    }

    fun generate(history: List<ChatTurn>): Flow<String> {
        val e = active ?: throw IllegalStateException("Model belum dimuat")
        return e.generate(history)
    }

    fun resetConversation() {
        active?.resetConversation()
    }

    fun unload() {
        active = null
        litert.unload()
        llama.unload()
    }
}
