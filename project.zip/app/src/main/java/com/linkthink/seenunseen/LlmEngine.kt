package com.linkthink.seenunseen

import android.content.Context
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

/** Pembungkus tunggal untuk LiteRT-LM. Seluruh UI hanya berbicara lewat kelas ini. */
class LlmEngine(private val context: Context) {

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    val modelFile: File
        get() = File(context.filesDir, "models/model.litertlm")

    fun hasModel(): Boolean = modelFile.exists() && modelFile.length() > 50L * 1024 * 1024

    suspend fun load() {
        withContext(Dispatchers.IO) {
            unload()
            val e = Engine(EngineConfig(modelPath = modelFile.absolutePath))
            e.initialize()
            engine = e
            conversation = e.createConversation()
        }
    }

    fun resetConversation() {
        val e = engine ?: return
        try {
            conversation?.close()
        } catch (t: Throwable) {
            // diabaikan
        }
        conversation = e.createConversation()
    }

    fun unload() {
        try {
            conversation?.close()
        } catch (t: Throwable) {
            // diabaikan
        }
        try {
            engine?.close()
        } catch (t: Throwable) {
            // diabaikan
        }
        conversation = null
        engine = null
    }

    fun generate(prompt: String): Flow<String> {
        val c = conversation ?: throw IllegalStateException("Model belum dimuat")
        return c.sendMessageAsync(prompt)
            .map { it.toString() }
            .flowOn(Dispatchers.Default)
    }
}
