package com.linkthink.seenunseen

import com.llamatik.library.platform.GenStream
import com.llamatik.library.platform.LlamaBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Mesin untuk berkas .gguf lewat llama.cpp (pustaka Llamatik).
 * Mesin ini tidak menyimpan percakapan, jadi seluruh riwayat dikirim ulang sebagai prompt
 * setiap giliran (diformat dengan templat chat milik model).
 */
class LlamaEngine : ChatEngine {

    companion object {
        const val CONTEXT = 4096
        const val MAX_TOKENS = 768
        const val THREADS = 4
    }

    @Volatile
    private var loaded = false

    private val running = AtomicBoolean(false)

    override suspend fun load(file: File) {
        withContext(Dispatchers.IO) {
            unload()
            LlamaBridge.updateGenerateParams(
                temperature = 0.7f,
                maxTokens = MAX_TOKENS,
                topP = 0.95f,
                topK = 40,
                repeatPenalty = 1.1f,
                contextLength = CONTEXT,
                numThreads = THREADS,
                useMmap = true,
                flashAttention = false,
                batchSize = 512,
                gpuLayers = 0
            )
            val ok = LlamaBridge.initGenerateModel(file.absolutePath)
            if (!ok) {
                throw IllegalStateException(
                    "Gagal memuat model GGUF (arsitektur tidak didukung versi llama.cpp ini, atau memori kurang)"
                )
            }
            loaded = true
        }
    }

    override fun resetConversation() {
        // Tidak ada percakapan di dalam mesin; cukup hentikan generasi yang sedang berjalan.
        if (running.get()) {
            try {
                LlamaBridge.nativeCancelGenerate()
            } catch (t: Throwable) {
                // diabaikan
            }
        }
    }

    override fun unload() {
        if (!loaded) return
        resetConversation()
        var waited = 0
        while (running.get() && waited < 3000) {
            Thread.sleep(100)
            waited += 100
        }
        try {
            LlamaBridge.shutdown()
        } catch (t: Throwable) {
            // diabaikan
        }
        loaded = false
        running.set(false)
    }

    override fun generate(history: List<ChatTurn>): Flow<String> {
        check(loaded) { "Model belum dimuat" }
        val prompt = buildPrompt(history)
        return callbackFlow {
            // Tunggu generasi sebelumnya selesai (mis. setelah tombol stop).
            var waited = 0
            while (running.get() && waited < 10_000) {
                delay(100)
                waited += 100
            }
            val finished = AtomicBoolean(false)
            running.set(true)
            val cb = object : GenStream {
                override fun onDelta(text: String) {
                    trySend(text)
                }

                override fun onComplete() {
                    finished.set(true)
                    running.set(false)
                    close()
                }

                override fun onError(message: String) {
                    finished.set(true)
                    running.set(false)
                    close(IllegalStateException(message))
                }
            }
            launch(Dispatchers.Default) {
                try {
                    LlamaBridge.generateStream(prompt, cb)
                    if (isClosedForSend) running.set(false)
                } catch (t: Throwable) {
                    finished.set(true)
                    running.set(false)
                    close(t)
                }
            }
            awaitClose {
                if (!finished.get()) {
                    try {
                        LlamaBridge.nativeCancelGenerate()
                    } catch (t: Throwable) {
                        // diabaikan
                    }
                }
            }
        }.buffer(Channel.UNLIMITED)
    }

    // ---------- Prompt ----------

    private fun buildPrompt(history: List<ChatTurn>): String {
        val turns = mergeSameRole(trimHistory(history))
        val msgs = turns.map { (if (it.user) "user" else "assistant") to it.text }
        val rendered = try {
            LlamaBridge.applyChatTemplate(msgs, true)
        } catch (t: Throwable) {
            null
        }
        if (!rendered.isNullOrBlank()) return rendered
        // Cadangan jika model tidak punya templat chat.
        return buildString {
            for (t in turns) {
                append(if (t.user) "User: " else "Assistant: ")
                append(t.text).append("\n")
            }
            append("Assistant:")
        }
    }

    /** Jaga riwayat tetap muat di jendela konteks (perkiraan kasar 2 karakter per token). */
    private fun trimHistory(h: List<ChatTurn>): List<ChatTurn> {
        var budget = (CONTEXT - MAX_TOKENS) * 2
        val out = ArrayDeque<ChatTurn>()
        for (t in h.asReversed()) {
            if (out.isNotEmpty() && budget - t.text.length < 0) break
            out.addFirst(t)
            budget -= t.text.length
        }
        while (out.size > 1 && !out.first().user) out.removeFirst()
        return out.toList()
    }

    private fun mergeSameRole(h: List<ChatTurn>): List<ChatTurn> {
        val out = ArrayList<ChatTurn>()
        for (t in h) {
            val last = out.lastOrNull()
            if (last != null && last.user == t.user) {
                out[out.lastIndex] = ChatTurn(t.user, last.text + "\n\n" + t.text)
            } else {
                out.add(t)
            }
        }
        return out
    }
}
