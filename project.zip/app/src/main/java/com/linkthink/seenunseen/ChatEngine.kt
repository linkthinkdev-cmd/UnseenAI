package com.linkthink.seenunseen

import kotlinx.coroutines.flow.Flow
import java.io.File

/** Satu giliran percakapan yang dikirim ke mesin. */
data class ChatTurn(val user: Boolean, val text: String)

/** Kontrak umum untuk semua mesin AI (LiteRT-LM dan llama.cpp). */
interface ChatEngine {
    suspend fun load(file: File)
    fun generate(history: List<ChatTurn>): Flow<String>
    fun resetConversation()
    fun unload()
}

enum class ModelKind(val label: String, val fileName: String) {
    LITERT("LiteRT-LM", "model.litertlm"),
    GGUF("GGUF", "model.gguf")
}
