package com.linkthink.seenunseen

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

/** Mesin untuk berkas .litertlm (Gemma 4 dll). Percakapan disimpan di dalam mesin. */
class LiteRtEngine : ChatEngine {

    @Volatile
    private var engine: Engine? = null

    @Volatile
    private var conversation: Conversation? = null

    private val lock = Any()

    override suspend fun load(file: File) {
        withContext(Dispatchers.IO) {
            unload()
            val e = Engine(EngineConfig(modelPath = file.absolutePath))
            e.initialize()
            engine = e
            // Percakapan dibuat saat pertama dipakai (lihat obtainConversation).
        }
    }

    override fun resetConversation() {
        val old: Conversation?
        synchronized(lock) {
            old = conversation
            conversation = null
        }
        try {
            old?.close()
        } catch (t: Throwable) {
            // diabaikan
        }
    }

    override fun unload() {
        resetConversation()
        val e = engine
        engine = null
        try {
            e?.close()
        } catch (t: Throwable) {
            // diabaikan
        }
    }

    private suspend fun obtainConversation(): Conversation {
        var lastError: Throwable? = null
        repeat(6) {
            synchronized(lock) {
                conversation?.let { return it }
                val e = engine ?: throw IllegalStateException("Model belum dimuat")
                try {
                    val c = e.createConversation()
                    conversation = c
                    return c
                } catch (t: Throwable) {
                    lastError = t
                }
            }
            delay(1000)
        }
        throw lastError ?: IllegalStateException("Gagal membuat percakapan")
    }

    override fun generate(history: List<ChatTurn>): Flow<String> {
        val prompt = history.lastOrNull { it.user }?.text
            ?: throw IllegalStateException("Tidak ada pesan pengguna")
        return flow {
            var attempt = 0
            while (true) {
                val c = obtainConversation()
                var emitted = false
                try {
                    emitAll(
                        c.sendMessageAsync(prompt).map {
                            emitted = true
                            it.toString()
                        }
                    )
                    return@flow
                } catch (e: IllegalStateException) {
                    val dead = e.message?.contains("alive", ignoreCase = true) == true
                    if (dead && !emitted && attempt < 2) {
                        attempt++
                        synchronized(lock) {
                            if (conversation === c) conversation = null
                        }
                        continue
                    }
                    throw e
                }
            }
        }.flowOn(Dispatchers.Default)
    }
}
