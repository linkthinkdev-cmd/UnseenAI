package com.linkthink.seenunseen

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Phase { NoModel, Copying, Loading, Ready, Generating }

data class ChatMsg(val id: Long, val fromUser: Boolean, val text: String)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val llm = LlmEngine(app)
    private val chatFile = File(app.filesDir, "chat.json")
    private val logFile = File(app.filesDir, "log.txt")

    val messages = mutableStateListOf<ChatMsg>()

    var phase by mutableStateOf(Phase.NoModel)
        private set
    var copyProgress by mutableFloatStateOf(0f)
        private set
    var logText by mutableStateOf("")
        private set
    var notice by mutableStateOf<String?>(null)
        private set
    var engineName by mutableStateOf("")
        private set

    private var job: Job? = null
    private var resetJob: Job? = null
    private var currentAiId = -1L
    private var nextId = 1L

    init {
        loadChat()
        logText = readLog()
        if (llm.installedKind() != null) loadModel() else phase = Phase.NoModel
    }

    // ---------- Model ----------

    fun loadModel() {
        phase = Phase.Loading
        notice = null
        viewModelScope.launch {
            try {
                val kind = llm.load()
                engineName = kind.label
                phase = Phase.Ready
            } catch (t: Throwable) {
                log("Gagal memuat model", t)
                engineName = ""
                notice = "Gagal memuat model. Buka menu > Log galat."
                phase = Phase.NoModel
            }
        }
    }

    fun importModel(uri: Uri) {
        if (phase == Phase.Copying || phase == Phase.Generating) return
        phase = Phase.Copying
        copyProgress = 0f
        notice = null
        viewModelScope.launch {
            val dir = llm.modelDir
            val tmp = File(dir, "model.tmp")
            try {
                withContext(Dispatchers.IO) {
                    llm.unload()
                    dir.mkdirs()
                    val cr = getApplication<Application>().contentResolver

                    // Jenis model dikenali dari 4 byte pertama: GGUF diawali "GGUF".
                    val head = ByteArray(4)
                    cr.openInputStream(uri)?.use { it.read(head) }
                    val kind = if (String(head, Charsets.US_ASCII) == "GGUF") ModelKind.GGUF else ModelKind.LITERT

                    var total = -1L
                    cr.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.SIZE)
                        if (i >= 0 && c.moveToFirst()) total = c.getLong(i)
                    }
                    val input = cr.openInputStream(uri)
                        ?: throw IllegalStateException("Tidak bisa membuka berkas")
                    input.use { ins ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var done = 0L
                            var lastPct = -1
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val pct = (done * 100 / total).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        copyProgress = done.toFloat() / total
                                    }
                                }
                            }
                        }
                    }
                    if (tmp.length() < 50L * 1024 * 1024) {
                        throw IllegalStateException("Berkas terlalu kecil, bukan model yang valid")
                    }
                    llm.removeModels()
                    if (!tmp.renameTo(llm.fileFor(kind))) {
                        throw IllegalStateException("Gagal menyimpan model")
                    }
                }
                loadModel()
            } catch (t: Throwable) {
                tmp.delete()
                log("Gagal menyalin model", t)
                notice = "Gagal menyalin model (ruang penyimpanan cukup?). Lihat Log galat."
                if (llm.installedKind() != null) loadModel() else phase = Phase.NoModel
            }
        }
    }

    // ---------- Chat ----------

    /** Riwayat yang dikirim ke mesin: semua pesan sebelum placeholder jawaban AI. */
    private fun buildHistory(): List<ChatTurn> =
        messages.dropLast(1)
            .filter { it.text.isNotBlank() && it.text != "(dihentikan)" && it.text != "(tidak ada jawaban)" }
            .map { ChatTurn(it.fromUser, it.text) }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || phase != Phase.Ready) return
        messages += ChatMsg(nextId++, true, text)
        val aiId = nextId++
        currentAiId = aiId
        messages += ChatMsg(aiId, false, "")
        val history = buildHistory()
        phase = Phase.Generating
        job = viewModelScope.launch {
            val sb = StringBuilder()
            try {
                resetJob?.let { withTimeoutOrNull(15_000) { it.join() } }
                llm.generate(history).collect { chunk ->
                    sb.append(chunk)
                    updateMessage(aiId, sb.toString())
                }
                if (sb.isEmpty()) updateMessage(aiId, "(tidak ada jawaban)")
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                log("Gagal menghasilkan teks", t)
                updateMessage(
                    aiId,
                    (sb.toString() + "\n\n⚠ Terjadi galat. Lihat menu > Log galat.").trim()
                )
            }
            phase = Phase.Ready
            saveChat()
        }
    }

    fun stop() {
        if (phase != Phase.Generating) return
        job?.cancel()
        val id = currentAiId
        val i = messages.indexOfLast { it.id == id }
        if (i >= 0 && messages[i].text.isEmpty()) updateMessage(id, "(dihentikan)")
        phase = Phase.Ready
        saveChat()
        resetJob = viewModelScope.launch { resetEngineConversation() }
    }

    fun newChat() {
        if (phase == Phase.Generating) {
            job?.cancel()
            phase = Phase.Ready
        }
        messages.clear()
        saveChat()
        resetJob = viewModelScope.launch { resetEngineConversation() }
    }

    fun dismissNotice() {
        notice = null
    }

    fun clearLog() {
        logFile.delete()
        logText = ""
    }

    private suspend fun resetEngineConversation() {
        withContext(Dispatchers.IO) {
            try {
                llm.resetConversation()
            } catch (t: Throwable) {
                log("Gagal mereset percakapan", t)
            }
        }
    }

    private fun updateMessage(id: Long, text: String) {
        val i = messages.indexOfLast { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text)
    }

    // ---------- Penyimpanan ----------

    private fun saveChat() {
        try {
            val arr = JSONArray()
            messages.forEach {
                arr.put(JSONObject().put("u", it.fromUser).put("t", it.text))
            }
            chatFile.writeText(arr.toString())
        } catch (t: Throwable) {
            log("Gagal menyimpan riwayat", t)
        }
    }

    private fun loadChat() {
        try {
            if (!chatFile.exists()) return
            val arr = JSONArray(chatFile.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages += ChatMsg(nextId++, o.getBoolean("u"), o.getString("t"))
            }
        } catch (t: Throwable) {
            log("Gagal membaca riwayat", t)
        }
    }

    // ---------- Log ----------

    private fun readLog(): String = try {
        if (logFile.exists()) logFile.readText().takeLast(20000) else ""
    } catch (t: Throwable) {
        ""
    }

    private fun log(msg: String, t: Throwable? = null) {
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val line = buildString {
            append("[").append(ts).append("] ").append(msg)
            if (t != null) {
                append("\n").append(t.stackTraceToString().take(2500))
            }
            append("\n\n")
        }
        try {
            logFile.appendText(line)
        } catch (e: Throwable) {
            // diabaikan
        }
        logText = (logText + line).takeLast(20000)
    }

    override fun onCleared() {
        llm.unload()
        super.onCleared()
    }
}
