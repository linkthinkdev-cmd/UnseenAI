package com.linkthink.seenunseen

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Phase { NoModel, Copying, Loading, Ready, Generating }

data class ChatMsg(val id: Long, val fromUser: Boolean, val text: String)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val llm = LlmEngine(app)
    private val chatFile = File(app.filesDir, "chat.json")
    private val logFile = File(app.filesDir, "log.txt")

    val messages = mutableStateListOf<ChatMsg>()

    var phase by mutableStateOf(Phase.NoModel)
        private set
    var copyProgress by mutableFloatStateOf(0f)
        private set
    var logText by mutableStateOf("")
        private set
    var notice by mutableStateOf<String?>(null)
        private set

    private var job: Job? = null
    private var nextId = 1L

    init {
        loadChat()
        logText = readLog()
        if (llm.hasModel()) loadModel() else phase = Phase.NoModel
    }

    // ---------- Model ----------

    fun loadModel() {
        phase = Phase.Loading
        notice = null
        viewModelScope.launch {
            try {
                llm.load()
                phase = Phase.Ready
            } catch (t: Throwable) {
                log("Gagal memuat model", t)
                notice = "Gagal memuat model. Buka menu > Log galat."
                phase = Phase.NoModel
            }
        }
    }

    fun importModel(uri: Uri) {
        if (phase == Phase.Copying || phase == Phase.Generating) return
        phase = Phase.Copying
        copyProgress = 0f
        notice = null
        viewModelScope.launch {
            val dir = llm.modelFile.parentFile!!
            val tmp = File(dir, "model.tmp")
            try {
                withContext(Dispatchers.IO) {
                    llm.unload()
                    dir.mkdirs()
                    val cr = getApplication<Application>().contentResolver
                    var total = -1L
                    cr.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.SIZE)
                        if (i >= 0 && c.moveToFirst()) total = c.getLong(i)
                    }
                    val input = cr.openInputStream(uri)
                        ?: throw IllegalStateException("Tidak bisa membuka berkas")
                    input.use { ins ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var done = 0L
                            var lastPct = -1
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val pct = (done * 100 / total).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        copyProgress = done.toFloat() / total
                                    }
                                }
                            }
                        }
                    }
                    if (tmp.length() < 50L * 1024 * 1024) {
                        throw IllegalStateException("Berkas terlalu kecil, bukan model yang valid")
                    }
                    llm.modelFile.delete()
                    if (!tmp.renameTo(llm.modelFile)) {
                        throw IllegalStateException("Gagal menyimpan model")
                    }
                }
                loadModel()
            } catch (t: Throwable) {
                tmp.delete()
                log("Gagal menyalin model", t)
                notice = "Gagal menyalin model (ruang penyimpanan cukup?). Lihat Log galat."
                if (llm.hasModel()) loadModel() else phase = Phase.NoModel
            }
        }
    }

    // ---------- Chat ----------

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || phase != Phase.Ready) return
        messages += ChatMsg(nextId++, true, text)
        val aiId = nextId++
        messages += ChatMsg(aiId, false, "")
        phase = Phase.Generating
        job = viewModelScope.launch {
            val sb = StringBuilder()
            try {
                llm.generate(text).collect { chunk ->
                    sb.append(chunk)
                    updateMessage(aiId, sb.toString())
                }
                if (sb.isEmpty()) updateMessage(aiId, "(tidak ada jawaban)")
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                log("Gagal menghasilkan teks", t)
                updateMessage(
                    aiId,
                    (sb.toString() + "\n\n⚠ Terjadi galat. Lihat menu > Log galat.").trim()
                )
            }
            phase = Phase.Ready
            saveChat()
        }
    }

    fun stop() {
        if (phase != Phase.Generating) return
        viewModelScope.launch {
            job?.cancelAndJoin()
            resetEngineConversation()
            phase = Phase.Ready
            saveChat()
        }
    }

    fun newChat() {
        viewModelScope.launch {
            val wasGenerating = phase == Phase.Generating
            if (wasGenerating) job?.cancelAndJoin()
            messages.clear()
            saveChat()
            resetEngineConversation()
            if (wasGenerating) phase = Phase.Ready
        }
    }

    fun dismissNotice() {
        notice = null
    }

    fun clearLog() {
        logFile.delete()
        logText = ""
    }

    private suspend fun resetEngineConversation() {
        withContext(Dispatchers.IO) {
            try {
                llm.resetConversation()
            } catch (t: Throwable) {
                log("Gagal mereset percakapan", t)
            }
        }
    }

    private fun updateMessage(id: Long, text: String) {
        val i = messages.indexOfLast { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text)
    }

    // ---------- Penyimpanan ----------

    private fun saveChat() {
        try {
            val arr = JSONArray()
            messages.forEach {
                arr.put(JSONObject().put("u", it.fromUser).put("t", it.text))
            }
            chatFile.writeText(arr.toString())
        } catch (t: Throwable) {
            log("Gagal menyimpan riwayat", t)
        }
    }

    private fun loadChat() {
        try {
            if (!chatFile.exists()) return
            val arr = JSONArray(chatFile.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages += ChatMsg(nextId++, o.getBoolean("u"), o.getString("t"))
            }
        } catch (t: Throwable) {
            log("Gagal membaca riwayat", t)
        }
    }

    // ---------- Log ----------

    private fun readLog(): String = try {
        if (logFile.exists()) logFile.readText().takeLast(20000) else ""
    } catch (t: Throwable) {
        ""
    }

    private fun log(msg: String, t: Throwable? = null) {
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val line = buildString {
            append("[").append(ts).append("] ").append(msg)
            if (t != null) {
                append("\n").append(t.stackTraceToString().take(2500))
            }
            append("\n\n")
        }
        try {
            logFile.appendText(line)
        } catch (e: Throwable) {
            // diabaikan
        }
        logText = (logText + line).takeLast(20000)
    }

    override fun onCleared() {
        llm.unload()
        super.onCleared()
    }
}
