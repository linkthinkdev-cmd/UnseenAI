package com.linkthink.seenunseen

import android.graphics.Typeface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.compose.material3.Text as M3Text

// ---------------------------------------------------------------------------
// Gaya terminal pixel
// ---------------------------------------------------------------------------

/** Persegi dengan sudut bertangga (pixel), bukan membulat. */
class PixelShape(private val stepDp: Dp = 3.dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val s = with(density) { stepDp.toPx() }
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(0f, 2 * s); lineTo(s, 2 * s); lineTo(s, s); lineTo(2 * s, s); lineTo(2 * s, 0f)
            lineTo(w - 2 * s, 0f); lineTo(w - 2 * s, s); lineTo(w - s, s); lineTo(w - s, 2 * s); lineTo(w, 2 * s)
            lineTo(w, h - 2 * s); lineTo(w - s, h - 2 * s); lineTo(w - s, h - s); lineTo(w - 2 * s, h - s); lineTo(w - 2 * s, h)
            lineTo(2 * s, h); lineTo(2 * s, h - s); lineTo(s, h - s); lineTo(s, h - 2 * s); lineTo(0f, h - 2 * s)
            close()
        }
        return Outline.Generic(p)
    }
}

data class TermFont(val family: FontFamily, val scale: Float)

val LocalTermFont = staticCompositionLocalOf { TermFont(FontFamily.Monospace, 1f) }

@Composable
private fun rememberTermFont(): TermFont {
    val ctx = LocalContext.current
    return remember {
        try {
            val tf = Typeface.createFromAsset(ctx.assets, "fonts/pixel.ttf")
            TermFont(FontFamily(tf), 1.35f)   // font pixel berukuran kecil, jadi diperbesar
        } catch (e: Throwable) {
            TermFont(FontFamily.Monospace, 1f)
        }
    }
}

@Composable
private fun T(
    text: String,
    color: Color = Color.White,
    size: Float = 16f,
    bold: Boolean = false,
    modifier: Modifier = Modifier
) {
    val f = LocalTermFont.current
    M3Text(
        text,
        color = color,
        fontSize = (size * f.scale).sp,
        lineHeight = (size * f.scale * 1.2f).sp,
        fontFamily = f.family,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        modifier = modifier
    )
}

@Composable
private fun PixelButton(
    label: String,
    bg: Color,
    edge: Color,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = remember { PixelShape(2.dp) }
    Box(
        Modifier
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .background(bg, shape)
            .border(2.dp, edge, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        T(label, Color.White, 17f, bold = true)
    }
}

// ---------------------------------------------------------------------------
// Layar utama
// ---------------------------------------------------------------------------

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val termFont = rememberTermFont()
    CompositionLocalProvider(LocalTermFont provides termFont) {
        ChatContent(vm)
    }
}

@Composable
private fun ChatContent(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("*/*")) }

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(0)
    }

    Box(Modifier.fillMaxSize().background(WallpaperBg)) {
        // Wallpaper dipikselkan: gambar kecil diperbesar tanpa penghalusan.
        Image(
            painter = painterResource(R.drawable.wallpaper_pixel),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillWidth,
            alignment = Alignment.Center,
            filterQuality = FilterQuality.None
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.62f)))
        // Garis pindai ala layar CRT
        Box(
            Modifier.fillMaxSize().drawBehind {
                val step = 4.dp.toPx()
                var y = 0f
                while (y < size.height) {
                    drawRect(
                        Color.Black.copy(alpha = 0.16f),
                        topLeft = Offset(0f, y),
                        size = Size(size.width, step / 2f)
                    )
                    y += step
                }
            }
        )

        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            // ----- Bar judul -----
            Row(
                Modifier.fillMaxWidth().padding(start = 14.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    T("[ SEEN THE UNSEEN ]", Color.White, 19f, bold = true)
                    T("status: " + statusLabel(vm.phase) + (if (vm.engineName.isNotEmpty() && vm.phase != Phase.NoModel) " · " + vm.engineName else ""), TealLight, 14f)
                }
                Box {
                    PixelButton("[MENU]", TealDark, TealEdge) { menuOpen = true }
                    DropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        containerColor = Color(0xFF0B0B0B)
                    ) {
                        DropdownMenuItem(
                            text = { T("> chat baru", Color.White, 16f) },
                            onClick = { menuOpen = false; vm.newChat() }
                        )
                        DropdownMenuItem(
                            text = { T("> pilih / ganti model", Color.White, 16f) },
                            onClick = { menuOpen = false; pick() }
                        )
                        DropdownMenuItem(
                            text = { T("> log galat", Color.White, 16f) },
                            onClick = { menuOpen = false; showLog = true }
                        )
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(2.dp).background(TealDark))

            // ----- Banner status -----
            Banner(vm, pick)
            vm.notice?.let {
                T(
                    "! " + it + " (ketuk untuk tutup)",
                    Color(0xFFFFB4C8),
                    14f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.dismissNotice() }
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }

            // ----- Daftar pesan -----
            val lastId = vm.messages.lastOrNull()?.id
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(vm.messages.asReversed(), key = { it.id }) { m ->
                        Bubble(
                            m = m,
                            generating = vm.phase == Phase.Generating,
                            cursor = vm.phase == Phase.Generating && m.id == lastId && !m.fromUser
                        )
                    }
                }
                if (vm.messages.isEmpty() && vm.phase == Phase.Ready) {
                    T(
                        "> ketik sesuatu untuk memulai_\n  (offline, tanpa internet)",
                        Color(0xFFD0D0D0),
                        16f,
                        modifier = Modifier.align(Alignment.Center).padding(32.dp)
                    )
                }
            }

            // ----- Input -----
            Box(Modifier.fillMaxWidth().height(2.dp).background(TealDark))
            InputBar(
                value = input,
                onValueChange = { input = it },
                phase = vm.phase,
                onSend = {
                    val t = input
                    if (t.isNotBlank()) {
                        input = ""
                        vm.send(t)
                    }
                },
                onStop = { vm.stop() }
            )
        }
    }

    if (showLog) LogDialog(vm) { showLog = false }
}

private fun statusLabel(p: Phase): String = when (p) {
    Phase.NoModel -> "model belum dipasang"
    Phase.Copying -> "menyalin model..."
    Phase.Loading -> "memuat model..."
    Phase.Ready -> "siap, offline"
    Phase.Generating -> "menjawab..."
}

private fun blockBar(filled: Int): String {
    val n = filled.coerceIn(0, 10)
    return "[" + "█".repeat(n) + "░".repeat(10 - n) + "]"
}

@Composable
private fun Banner(vm: ChatViewModel, onPick: () -> Unit) {
    when (vm.phase) {
        Phase.NoModel -> BannerCard {
            T("! model belum dipasang", Color.White, 17f, bold = true)
            T(
                "Pilih berkas model: .gguf (llama.cpp) atau .litertlm (LiteRT-LM). Bisa diunduh dari Hugging Face.",
                Color(0xFFE6E6E6),
                15f,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            PixelButton("[PILIH BERKAS MODEL]", TealDark, TealEdge, onClick = onPick)
        }
        Phase.Copying -> BannerCard {
            T("> menyalin model ke aplikasi", Color.White, 16f)
            T(blockBar((vm.copyProgress * 10).toInt()), TealLight, 18f, modifier = Modifier.padding(top = 6.dp))
        }
        Phase.Loading -> {
            val frame by produceState(0) {
                while (true) {
                    delay(250)
                    value = (value + 1) % 11
                }
            }
            BannerCard {
                T("> memuat model, mohon tunggu", Color.White, 16f)
                T(blockBar(frame), TealLight, 18f, modifier = Modifier.padding(top = 6.dp))
            }
        }
        else -> {}
    }
}

@Composable
private fun BannerCard(content: @Composable () -> Unit) {
    val shape = remember { PixelShape(3.dp) }
    Surface(
        color = PanelBg,
        shape = shape,
        border = BorderStroke(2.dp, TealEdge),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Column(Modifier.padding(14.dp)) { content() }
    }
}

@Composable
private fun Bubble(m: ChatMsg, generating: Boolean, cursor: Boolean) {
    val mine = m.fromUser
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    var cursorOn by remember { mutableStateOf(true) }
    LaunchedEffect(cursor) {
        while (cursor) {
            delay(450)
            cursorOn = !cursorOn
        }
    }

    val shape = remember { PixelShape(3.dp) }
    AnimatedVisibility(
        visible = visible,
        // fade bertahap (bukan halus) agar terasa seperti pixel
        enter = fadeIn(tween(160, easing = Easing { (it * 4).toInt() / 4f }))
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
            horizontalAlignment = if (mine) Alignment.End else Alignment.Start
        ) {
            T(
                if (mine) "kamu@hp:~$" else "gemma@lokal:~$",
                if (mine) PinkLight else TealLight,
                13f,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
            Surface(
                color = if (mine) MagentaDark else TealDark,
                shape = shape,
                border = BorderStroke(2.dp, if (mine) MagentaEdge else TealEdge),
                modifier = Modifier.widthIn(max = 330.dp)
            ) {
                if (m.text.isEmpty() && generating && !mine) {
                    TypingBlock()
                } else {
                    SelectionContainer {
                        val shown = if (cursor) m.text + (if (cursorOn) "█" else " ") else m.text
                        T(
                            shown,
                            Color.White,
                            17f,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingBlock() {
    val t = rememberInfiniteTransition(label = "blok")
    val a by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(900, easing = Easing { if (it < 0.5f) 1f else 0f }),
            RepeatMode.Restart
        ),
        label = "kedip"
    )
    Box(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
        T("█", TealLight, 18f, modifier = Modifier.alpha(a))
    }
}

@Composable
private fun InputBar(
    value: String,
    onValueChange: (String) -> Unit,
    phase: Phase,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    val f = LocalTermFont.current
    val generating = phase == Phase.Generating
    val canSend = phase == Phase.Ready && value.isNotBlank()
    val inputShape = remember { PixelShape(2.dp) }
    Row(
        Modifier.fillMaxWidth().background(PanelBg).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        T("> ", TealLight, 20f, bold = true)
        Box(
            Modifier
                .weight(1f)
                .clip(inputShape)
                .background(Color.Black.copy(alpha = 0.6f), inputShape)
                .border(2.dp, TealDark, inputShape)
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = (17f * f.scale).sp,
                    fontFamily = f.family
                ),
                cursorBrush = SolidColor(TealLight),
                maxLines = 5,
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    if (value.isEmpty()) {
                        T("ketik pesan_", Color(0xFFB8B8B8), 17f)
                    }
                    inner()
                }
            )
        }
        Spacer(Modifier.size(8.dp))
        if (generating) {
            PixelButton("[STOP]", MagentaDark, MagentaEdge, onClick = onStop)
        } else {
            PixelButton("[KIRIM]", MagentaDark, MagentaEdge, enabled = canSend, onClick = onSend)
        }
    }
}

@Composable
private fun LogDialog(vm: ChatViewModel, onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val shape = remember { PixelShape(3.dp) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF0B0B0B),
        shape = shape,
        title = { T("> log_galat", TealLight, 19f, bold = true) },
        text = {
            Box(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                SelectionContainer {
                    T(vm.logText.ifEmpty { "(kosong)" }, Color(0xFFE6E6E6), 13f)
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PixelButton("[SALIN]", TealDark, TealEdge) { clipboard.setText(AnnotatedString(vm.logText)) }
                PixelButton("[HAPUS]", MagentaDark, MagentaEdge) { vm.clearLog() }
                PixelButton("[TUTUP]", Color(0xFF222222), Color(0xFF555555), onClick = onClose)
            }
        }
    )
}
