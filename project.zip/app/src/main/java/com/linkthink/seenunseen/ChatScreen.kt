package com.linkthink.seenunseen

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ChatScreen(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("*/*")) }

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(0)
    }

    Box(Modifier.fillMaxSize().background(WallpaperBg)) {
        Image(
            painter = painterResource(R.drawable.wallpaper),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillWidth,
            alignment = Alignment.Center
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.64f)))

        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            // ----- Bar atas -----
            Row(
                Modifier.fillMaxWidth()
                    .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Seen the Unseen",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(statusLabel(vm.phase), color = TealLight, fontSize = 12.sp)
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu", tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        containerColor = Color(0xFF1A1A1A)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Chat baru", color = Color.White) },
                            onClick = { menuOpen = false; vm.newChat() }
                        )
                        DropdownMenuItem(
                            text = { Text("Pilih / ganti model", color = Color.White) },
                            onClick = { menuOpen = false; pick() }
                        )
                        DropdownMenuItem(
                            text = { Text("Log galat", color = Color.White) },
                            onClick = { menuOpen = false; showLog = true }
                        )
                    }
                }
            }

            // ----- Banner status -----
            Banner(vm, pick)
            vm.notice?.let {
                Text(
                    it + "  (ketuk untuk tutup)",
                    color = Color(0xFFFFB4C8),
                    fontSize = 13.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.dismissNotice() }
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            // ----- Daftar pesan -----
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(vm.messages.asReversed(), key = { it.id }) { m ->
                        Bubble(m, generating = vm.phase == Phase.Generating)
                    }
                }
                if (vm.messages.isEmpty() && vm.phase == Phase.Ready) {
                    Text(
                        "Tanya apa saja. Semua berjalan offline di ponselmu.",
                        color = Color(0xFFD0D0D0),
                        fontSize = 15.sp,
                        modifier = Modifier.align(Alignment.Center).padding(32.dp)
                    )
                }
            }

            // ----- Input -----
            InputBar(
                value = input,
                onValueChange = { input = it },
                phase = vm.phase,
                onSend = {
                    val t = input
                    if (t.isNotBlank()) {
                        input = ""
                        vm.send(t)
                    }
                },
                onStop = { vm.stop() }
            )
        }
    }

    if (showLog) LogDialog(vm) { showLog = false }
}

private fun statusLabel(p: Phase): String = when (p) {
    Phase.NoModel -> "Model belum dipasang"
    Phase.Copying -> "Menyalin model…"
    Phase.Loading -> "Memuat model…"
    Phase.Ready -> "Siap · offline"
    Phase.Generating -> "Menjawab…"
}

@Composable
private fun Banner(vm: ChatViewModel, onPick: () -> Unit) {
    when (vm.phase) {
        Phase.NoModel -> BannerCard {
            Text(
                "Model belum dipasang",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            Text(
                "Unduh Gemma 4 E2B (.litertlm) dari Hugging Face, lalu pilih berkasnya di sini.",
                color = Color(0xFFE6E6E6),
                fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )
            Button(
                onClick = onPick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealDark,
                    contentColor = Color.White
                )
            ) {
                Text("Pilih berkas model")
            }
        }
        Phase.Copying -> BannerCard {
            Text("Menyalin model ke aplikasi…", color = Color.White, fontSize = 14.sp)
            LinearProgressIndicator(
                progress = { vm.copyProgress },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                color = TealLight,
                trackColor = Color(0x33FFFFFF)
            )
        }
        Phase.Loading -> BannerCard {
            Text("Memuat model, mohon tunggu…", color = Color.White, fontSize = 14.sp)
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                color = TealLight,
                trackColor = Color(0x33FFFFFF)
            )
        }
        else -> {}
    }
}

@Composable
private fun BannerCard(content: @Composable () -> Unit) {
    Surface(
        color = PanelBg,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Column(Modifier.padding(14.dp)) { content() }
    }
}

@Composable
private fun Bubble(m: ChatMsg, generating: Boolean) {
    val mine = m.fromUser
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (mine) 16.dp else 4.dp,
        bottomEnd = if (mine) 4.dp else 16.dp
    )
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(220)) + slideInVertically(tween(220)) { it / 4 }
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 3.dp),
            horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
        ) {
            Surface(
                color = if (mine) MagentaDark else TealDark,
                shape = shape,
                modifier = Modifier.widthIn(max = 310.dp)
            ) {
                if (m.text.isEmpty() && generating && !mine) {
                    TypingDots()
                } else {
                    SelectionContainer {
                        Text(
                            m.text,
                            color = Color.White,
                            fontSize = 16.sp,
                            lineHeight = 22.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(Modifier.padding(horizontal = 14.dp, vertical = 14.dp)) {
        repeat(3) { i ->
            val a by t.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(600),
                    RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 150)
                ),
                label = "dot$i"
            )
            Box(
                Modifier
                    .padding(horizontal = 2.dp)
                    .size(8.dp)
                    .alpha(a)
                    .background(Color.White, CircleShape)
            )
        }
    }
}

@Composable
private fun InputBar(
    value: String,
    onValueChange: (String) -> Unit,
    phase: Phase,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    val generating = phase == Phase.Generating
    val canSend = phase == Phase.Ready && value.isNotBlank()
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Box(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(24.dp))
                .background(PanelBg)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                maxLines = 5,
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    if (value.isEmpty()) {
                        Text("Ketik pesan…", color = Color(0xFFB8B8B8), fontSize = 16.sp)
                    }
                    inner()
                }
            )
        }
        Spacer(Modifier.size(8.dp))
        Box(
            Modifier
                .size(48.dp)
                .alpha(if (generating || canSend) 1f else 0.4f)
                .clip(CircleShape)
                .background(MagentaDark)
                .clickable(enabled = generating || canSend) {
                    if (generating) onStop() else onSend()
                },
            contentAlignment = Alignment.Center
        ) {
            if (generating) {
                Box(Modifier.size(16.dp).background(Color.White, RoundedCornerShape(3.dp)))
            } else {
                Icon(Icons.Default.Send, contentDescription = "Kirim", tint = Color.White)
            }
        }
    }
}

@Composable
private fun LogDialog(vm: ChatViewModel, onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF151515),
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = { Text("Log galat") },
        text = {
            Box(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                SelectionContainer {
                    Text(
                        vm.logText.ifEmpty { "(kosong)" },
                        color = Color(0xFFE6E6E6),
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = { clipboard.setText(AnnotatedString(vm.logText)) }) {
                    Text("Salin", color = TealLight)
                }
                TextButton(onClick = { vm.clearLog() }) { Text("Hapus", color = TealLight) }
                TextButton(onClick = onClose) { Text("Tutup", color = TealLight) }
            }
        }
    )
}
