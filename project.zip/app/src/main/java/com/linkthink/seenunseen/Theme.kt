package com.linkthink.seenunseen

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val MagentaDark = Color(0xFF7A1048)   // bubble pengguna
val TealDark = Color(0xFF0B5F62)      // bubble AI
val TealLight = Color(0xFF6FE3DC)     // teks status / aksen
val WallpaperBg = Color(0xFF210748)   // warna dasar gambar wallpaper
val PanelBg = Color(0xE6141414)

private val Scheme = darkColorScheme(
    primary = MagentaDark,
    onPrimary = Color.White,
    secondary = TealDark,
    onSecondary = Color.White,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color(0xFF141414),
    onSurface = Color.White
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
