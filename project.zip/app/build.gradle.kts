plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.linkthink.seenunseen"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.linkthink.seenunseen"
        minSdk = 31
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        jniLibs.pickFirsts += "**/libc++_shared.so"
    }
}

// Mengunduh font pixel (VT323, lisensi OFL) saat build. Jika gagal, aplikasi memakai font monospace.
val pixelFontFile = layout.projectDirectory.file("src/main/assets/fonts/pixel.ttf").asFile
val downloadPixelFont = tasks.register("downloadPixelFont") {
    doLast {
        if (!pixelFontFile.exists()) {
            try {
                pixelFontFile.parentFile.mkdirs()
                java.net.URL("https://raw.githubusercontent.com/google/fonts/main/ofl/vt323/VT323-Regular.ttf")
                    .openStream().use { input ->
                        pixelFontFile.outputStream().use { out -> input.copyTo(out) }
                    }
            } catch (e: Exception) {
                println("Font pixel tidak terunduh, memakai monospace: " + e.message)
                pixelFontFile.delete()
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadPixelFont) }

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.16.1")
    implementation("com.llamatik:library:1.7.0")
}
