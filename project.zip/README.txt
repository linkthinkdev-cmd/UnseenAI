Seen the Unseen - chat AI offline (Gemma 4 E2B lewat LiteRT-LM).
Build: gradle assembleDebug  -> app/build/outputs/apk/debug/
Model: pilih berkas .litertlm lewat tombol di dalam aplikasi.
